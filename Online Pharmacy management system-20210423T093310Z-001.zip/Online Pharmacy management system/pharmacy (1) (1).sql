-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 10, 2021 at 07:22 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add user details', 7, 'add_userdetails'),
(26, 'Can change user details', 7, 'change_userdetails'),
(27, 'Can delete user details', 7, 'delete_userdetails'),
(28, 'Can view user details', 7, 'view_userdetails'),
(29, 'Can add company', 8, 'add_company'),
(30, 'Can change company', 8, 'change_company'),
(31, 'Can delete company', 8, 'delete_company'),
(32, 'Can view company', 8, 'view_company'),
(33, 'Can add medicine', 9, 'add_medicine'),
(34, 'Can change medicine', 9, 'change_medicine'),
(35, 'Can delete medicine', 9, 'delete_medicine'),
(36, 'Can view medicine', 9, 'view_medicine'),
(37, 'Can add gender', 10, 'add_gender'),
(38, 'Can change gender', 10, 'change_gender'),
(39, 'Can delete gender', 10, 'delete_gender'),
(40, 'Can view gender', 10, 'view_gender'),
(41, 'Can add login', 11, 'add_login'),
(42, 'Can change login', 11, 'change_login'),
(43, 'Can delete login', 11, 'delete_login'),
(44, 'Can view login', 11, 'view_login'),
(45, 'Can add staff details', 12, 'add_staffdetails'),
(46, 'Can change staff details', 12, 'change_staffdetails'),
(47, 'Can delete staff details', 12, 'delete_staffdetails'),
(48, 'Can view staff details', 12, 'view_staffdetails'),
(49, 'Can add cart_item', 13, 'add_cart_item'),
(50, 'Can change cart_item', 13, 'change_cart_item'),
(51, 'Can delete cart_item', 13, 'delete_cart_item'),
(52, 'Can view cart_item', 13, 'view_cart_item'),
(53, 'Can add cart', 14, 'add_cart'),
(54, 'Can change cart', 14, 'change_cart'),
(55, 'Can delete cart', 14, 'delete_cart'),
(56, 'Can view cart', 14, 'view_cart'),
(57, 'Can add invoice', 15, 'add_invoice'),
(58, 'Can change invoice', 15, 'change_invoice'),
(59, 'Can delete invoice', 15, 'delete_invoice'),
(60, 'Can view invoice', 15, 'view_invoice'),
(61, 'Can add sales', 16, 'add_sales'),
(62, 'Can change sales', 16, 'change_sales'),
(63, 'Can delete sales', 16, 'delete_sales'),
(64, 'Can view sales', 16, 'view_sales'),
(65, 'Can add supplier', 17, 'add_supplier'),
(66, 'Can change supplier', 17, 'change_supplier'),
(67, 'Can delete supplier', 17, 'delete_supplier'),
(68, 'Can view supplier', 17, 'view_supplier'),
(69, 'Can add s_invoice', 18, 'add_s_invoice'),
(70, 'Can change s_invoice', 18, 'change_s_invoice'),
(71, 'Can delete s_invoice', 18, 'delete_s_invoice'),
(72, 'Can view s_invoice', 18, 'view_s_invoice'),
(73, 'Can add supplier_med', 19, 'add_supplier_med'),
(74, 'Can change supplier_med', 19, 'change_supplier_med'),
(75, 'Can delete supplier_med', 19, 'delete_supplier_med'),
(76, 'Can view supplier_med', 19, 'view_supplier_med'),
(77, 'Can add sales_supplier', 20, 'add_sales_supplier'),
(78, 'Can change sales_supplier', 20, 'change_sales_supplier'),
(79, 'Can delete sales_supplier', 20, 'delete_sales_supplier'),
(80, 'Can view sales_supplier', 20, 'view_sales_supplier'),
(81, 'Can add lowstock', 21, 'add_lowstock'),
(82, 'Can change lowstock', 21, 'change_lowstock'),
(83, 'Can delete lowstock', 21, 'delete_lowstock'),
(84, 'Can view lowstock', 21, 'view_lowstock');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `common_cart`
--

CREATE TABLE `common_cart` (
  `cartid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `medicineid_id` int(11) NOT NULL,
  `userid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `common_cart_item`
--

CREATE TABLE `common_cart_item` (
  `pid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `medicineid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `common_gender`
--

CREATE TABLE `common_gender` (
  `id` int(11) NOT NULL,
  `gender` varchar(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `common_gender`
--

INSERT INTO `common_gender` (`id`, `gender`) VALUES
(1, 'Male'),
(2, 'Female');

-- --------------------------------------------------------

--
-- Table structure for table `common_invoice`
--

CREATE TABLE `common_invoice` (
  `invoiceid` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `amt_payable` decimal(10,2) NOT NULL,
  `amt_paid` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `paymentmode` varchar(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `userid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `common_invoice`
--

INSERT INTO `common_invoice` (`invoiceid`, `customer_name`, `amt_payable`, `amt_paid`, `balance`, `paymentmode`, `date`, `userid_id`) VALUES
(12, 'Peter', '2130.00', '0.00', '2130.00', 'Cash', '2021-04-05', 9),
(13, 'Peter', '75.00', '0.00', '75.00', 'Cash', '2021-04-10', 9),
(14, 'Peter', '455.00', '0.00', '455.00', 'Cash', '2021-04-10', 9),
(15, 'Deepak', '27.00', '27.00', '0.00', 'Cash', '2021-04-10', 10),
(16, 'Deepak', '27.00', '27.00', '0.00', 'Cash', '2021-04-10', 10),
(17, 'Peter', '64.00', '0.00', '64.00', 'Cash', '2021-04-10', 9),
(18, 'Peter', '27.00', '0.00', '27.00', 'Cash', '2021-04-10', 9),
(19, 'Peter', '27.00', '0.00', '27.00', 'Cash', '2021-04-10', 9),
(20, 'Peter', '27.00', '0.00', '27.00', 'Card', '2021-04-10', 9),
(21, 'Peter', '50.00', '0.00', '50.00', 'Card', '2021-04-10', 9),
(22, 'Peter', '50.00', '0.00', '50.00', 'Card', '2021-04-10', 9),
(23, 'Peter', '8.00', '0.00', '8.00', 'Card', '2021-04-10', 9),
(24, 'Peter', '12.00', '0.00', '12.00', 'Card', '2021-04-10', 9),
(25, 'Peter', '27.00', '0.00', '27.00', 'Card', '2021-04-10', 9),
(26, 'Peter', '32.00', '0.00', '32.00', 'Card', '2021-04-10', 9),
(27, 'Peter', '32.00', '0.00', '32.00', 'Card', '2021-04-10', 9);

-- --------------------------------------------------------

--
-- Table structure for table `common_login`
--

CREATE TABLE `common_login` (
  `userid` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(10) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `common_login`
--

INSERT INTO `common_login` (`userid`, `username`, `password`, `role`) VALUES
(1, 'admin', '123', 0),
(9, 'peter@gmail.com', '123456', 2),
(10, 'john@gmail.com', '123456', 1),
(12, 'supplier1@gmail.com', '123456', 3),
(13, 'supplier2@gmail.com', '123456', 3),
(14, 'supplier3@gmail.com', '123456', 3),
(15, 'sinju.p@ipsrsolutions.com', '1234', 3);

-- --------------------------------------------------------

--
-- Table structure for table `common_sales`
--

CREATE TABLE `common_sales` (
  `salesid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `month` varchar(5) NOT NULL,
  `year` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoiceid_id` int(11) NOT NULL,
  `medicineid_id` int(11) NOT NULL,
  `userid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `common_sales`
--

INSERT INTO `common_sales` (`salesid`, `quantity`, `amount`, `month`, `year`, `date`, `invoiceid_id`, `medicineid_id`, `userid_id`) VALUES
(11, 45, '1215.00', '4', 2021, '2021-04-10', 13, 5, 9),
(12, 15, '75.00', '4', 2021, '2021-04-10', 13, 6, 9),
(13, 15, '405.00', '4', 2021, '2021-04-10', 14, 5, 9),
(14, 10, '50.00', '4', 2021, '2021-04-10', 14, 6, 9),
(15, 1, '27.00', '4', 2021, '2021-04-10', 16, 5, 10),
(16, 2, '10.00', '4', 2021, '2021-04-10', 17, 6, 9),
(17, 2, '54.00', '4', 2021, '2021-04-10', 17, 5, 9),
(18, 1, '27.00', '4', 2021, '2021-04-10', 18, 5, 9),
(19, 1, '27.00', '4', 2021, '2021-04-10', 20, 5, 9),
(20, 25, '50.00', '4', 2021, '2021-04-10', 21, 7, 9),
(21, 4, '8.00', '4', 2021, '2021-04-10', 23, 7, 9),
(22, 6, '12.00', '4', 2021, '2021-04-10', 24, 7, 9),
(23, 1, '27.00', '4', 2021, '2021-04-10', 25, 5, 9),
(24, 1, '27.00', '4', 2021, '2021-04-10', 26, 5, 9),
(25, 1, '5.00', '4', 2021, '2021-04-10', 26, 6, 9),
(26, 1, '27.00', '4', 2021, '2021-04-10', 27, 5, 9),
(27, 1, '5.00', '4', 2021, '2021-04-10', 27, 6, 9);

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(14, 'common', 'cart'),
(13, 'common', 'cart_item'),
(10, 'common', 'gender'),
(15, 'common', 'invoice'),
(11, 'common', 'login'),
(16, 'common', 'sales'),
(5, 'contenttypes', 'contenttype'),
(8, 'head', 'company'),
(9, 'head', 'medicine'),
(6, 'sessions', 'session'),
(21, 'staff', 'lowstock'),
(12, 'staff', 'staffdetails'),
(20, 'supplier', 'sales_supplier'),
(17, 'supplier', 'supplier'),
(19, 'supplier', 'supplier_med'),
(18, 'supplier', 's_invoice'),
(7, 'user', 'userdetails');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2021-03-28 14:43:54.525074'),
(2, 'auth', '0001_initial', '2021-03-28 14:43:56.118801'),
(3, 'admin', '0001_initial', '2021-03-28 14:44:05.853325'),
(4, 'admin', '0002_logentry_remove_auto_add', '2021-03-28 14:44:09.650221'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2021-03-28 14:44:09.759598'),
(6, 'contenttypes', '0002_remove_content_type_name', '2021-03-28 14:44:11.494053'),
(7, 'auth', '0002_alter_permission_name_max_length', '2021-03-28 14:44:12.665940'),
(8, 'auth', '0003_alter_user_email_max_length', '2021-03-28 14:44:13.962806'),
(9, 'auth', '0004_alter_user_username_opts', '2021-03-28 14:44:14.025280'),
(10, 'auth', '0005_alter_user_last_login_null', '2021-03-28 14:44:15.056575'),
(11, 'auth', '0006_require_contenttypes_0002', '2021-03-28 14:44:15.103472'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2021-03-28 14:44:15.228448'),
(13, 'auth', '0008_alter_user_username_max_length', '2021-03-28 14:44:16.978497'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2021-03-28 14:44:18.806621'),
(15, 'auth', '0010_alter_group_name_max_length', '2021-03-28 14:44:20.525419'),
(16, 'auth', '0011_update_proxy_permissions', '2021-03-28 14:44:20.603492'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2021-03-28 14:44:21.572309'),
(18, 'common', '0001_initial', '2021-03-28 14:44:22.478530'),
(19, 'head', '0001_initial', '2021-03-28 14:44:23.650409'),
(20, 'sessions', '0001_initial', '2021-03-28 14:44:25.212956'),
(21, 'user', '0001_initial', '2021-03-28 14:44:25.994191'),
(22, 'head', '0002_medicine_storage_location', '2021-03-28 15:02:29.304845'),
(23, 'staff', '0001_initial', '2021-03-29 05:15:24.948085'),
(24, 'staff', '0002_staffdetails_email', '2021-03-29 05:17:43.477589'),
(25, 'common', '0002_cart_cart_item_invoice', '2021-04-04 16:53:08.924293'),
(26, 'common', '0003_sales', '2021-04-04 17:48:51.330455'),
(27, 'common', '0004_sales_userid', '2021-04-04 20:39:25.821596'),
(28, 'head', '0003_medicine_image', '2021-04-10 01:52:09.768128'),
(29, 'supplier', '0001_initial', '2021-04-10 02:44:56.695278'),
(30, 'supplier', '0002_supplier_status', '2021-04-10 03:46:06.101850'),
(31, 'supplier', '0003_auto_20210410_1625', '2021-04-10 10:55:40.464642'),
(32, 'supplier', '0004_auto_20210410_2008', '2021-04-10 14:38:25.832258'),
(33, 'staff', '0003_lowstock', '2021-04-10 16:00:43.325898');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('u7jei31mip3tw8dxu3umrzbyph0bphzg', 'eyJ1c2VyaWQiOjEsInVzZXJfbmFtZSI6ImFkbWluIn0:1lVBQB:nt6SHNqlZHJDjdR1YbiLmPFyt2tV6TO5Fb0mWU1MmbY', '2021-04-24 11:04:59.428176');

-- --------------------------------------------------------

--
-- Table structure for table `head_company`
--

CREATE TABLE `head_company` (
  `companyid` int(11) NOT NULL,
  `companyname` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `head_company`
--

INSERT INTO `head_company` (`companyid`, `companyname`) VALUES
(1, 'Sunpharma'),
(2, 'Abott');

-- --------------------------------------------------------

--
-- Table structure for table `head_medicine`
--

CREATE TABLE `head_medicine` (
  `medicineid` int(11) NOT NULL,
  `medicinename` varchar(100) NOT NULL,
  `batchno` int(11) NOT NULL,
  `mfg_date` date NOT NULL,
  `expiry` date NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `description` varchar(200) NOT NULL,
  `dosage` varchar(200) NOT NULL,
  `side_effects` varchar(200) NOT NULL,
  `created_on` date NOT NULL,
  `updatedon` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `storage_location` varchar(20) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `head_medicine`
--

INSERT INTO `head_medicine` (`medicineid`, `medicinename`, `batchno`, `mfg_date`, `expiry`, `price_per_unit`, `description`, `dosage`, `side_effects`, `created_on`, `updatedon`, `quantity`, `company_id`, `storage_location`, `image`) VALUES
(5, 'Diamet 500', 3453453, '2021-04-01', '2021-05-10', '27.00', 'Diamet 500mg Tab 10`S contains metformin, which belongs to the biguanide group of medicines used to treat type 2 diabetes mellitus (also called known as \'non-insulin dependent diabetes\').', 'Take this medicine with or after a meal to reduce it\'s side effects,  Consult your doctor for the appropriate dosage of Diamet 850mg Tab 10`S', 'Nausea ,Vomiting, Mild diarrhoea, Stomach pain', '2021-04-10', '2021-04-10', 132, 1, 'A103', 'images/download.jpg'),
(6, 'Ecospirin 75mg strip of 10 tablets', 76545678, '2021-04-01', '2021-09-13', '5.00', 'Ecosprin 75 tablet is an antiplatelet medicine. It is used to prevent the risk of heart attacks, stroke and chest pain (heart-related).', 'Swallow Ecosprin 75 mg Tablet as a whole with a glass of water. Take it as advised by your doctor and try to take it at the same time.', 'Bleeding ,Indigestion ,Hives, Breathing difficulty ,Runny nose ,Itching', '2021-04-10', '2021-04-10', 1, 1, 'B102', 'images/download_6.jpg'),
(7, 'Paracetamol 500mg', 2147483647, '2021-02-01', '2021-04-12', '2.00', 'For Fever, Headache, Body Pain', 'Swallow as whole with water', 'Nausea ,Vomiting, Mild diarrhoea, Stomach pain', '2021-04-10', '2021-04-10', 65, 1, '2', 'images/download_5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `staff_lowstock`
--

CREATE TABLE `staff_lowstock` (
  `id` int(11) NOT NULL,
  `cid_id` int(11) NOT NULL,
  `mid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_lowstock`
--

INSERT INTO `staff_lowstock` (`id`, `cid_id`, `mid_id`) VALUES
(1, 2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `staff_staffdetails`
--

CREATE TABLE `staff_staffdetails` (
  `id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `employeeID` int(11) NOT NULL,
  `gender_id` int(11) NOT NULL,
  `staffid_id` int(11) NOT NULL,
  `email` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_staffdetails`
--

INSERT INTO `staff_staffdetails` (`id`, `firstname`, `lastname`, `phone`, `employeeID`, `gender_id`, `staffid_id`, `email`) VALUES
(5, 'John', 'K', 7907791788, 345009756, 1, 10, 'john@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_sales_supplier`
--

CREATE TABLE `supplier_sales_supplier` (
  `salesid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `month` varchar(5) NOT NULL,
  `year` int(11) NOT NULL,
  `date` varchar(50) NOT NULL,
  `invoiceid_id` int(11) NOT NULL,
  `medicineid_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_sales_supplier`
--

INSERT INTO `supplier_sales_supplier` (`salesid`, `quantity`, `amount`, `month`, `year`, `date`, `invoiceid_id`, `medicineid_id`, `supplier_id`) VALUES
(1, 2, '4.00', '4', 2021, '2020-03-21', 3, 1, 12),
(2, 2, '4.00', '4', 2021, '2020-03-21', 4, 1, 12),
(3, 2, '4.00', '4', 2021, '2020-03-21', 5, 1, 12),
(4, 2, '4.00', '4', 2021, '2020-03-21', 6, 1, 12),
(5, 1000, '2000.00', '4', 2021, '2020-03-21', 7, 1, 12),
(6, 4, '8.00', '4', 2021, '2020-03-21', 8, 1, 12),
(7, 3, '6.00', '4', 2021, '2020-03-21', 9, 1, 12);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_supplier`
--

CREATE TABLE `supplier_supplier` (
  `id` int(11) NOT NULL,
  `sname` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `addressline1` varchar(30) NOT NULL,
  `addressline2` varchar(30) NOT NULL,
  `district` varchar(12) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `userid_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_supplier`
--

INSERT INTO `supplier_supplier` (`id`, `sname`, `phone`, `addressline1`, `addressline2`, `district`, `pincode`, `userid_id`, `status`) VALUES
(1, 'Supplier1', 7907791788, 'MDRA 100', 'XYZ villa', 'Kottayam', '673456', 12, 1),
(2, 'Supplier2', 43526265675, 'STVM HJK', 'Kakkanad', 'Ernakulam', '673456', 13, 1),
(3, 'Supplier3', 9989569895, '123/45', 'RYH HNDFNG DDR', 'Trivandrum', '567567', 14, 1),
(4, 'sinju', 7907791788, 'MDRA 100', 'Kakkanad', 'Ernakulam', '673456', 15, 0);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_supplier_med`
--

CREATE TABLE `supplier_supplier_med` (
  `medicineid` int(11) NOT NULL,
  `medicinename` varchar(100) NOT NULL,
  `batchno` int(11) NOT NULL,
  `mfg_date` date NOT NULL,
  `expiry` date NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `description` varchar(200) NOT NULL,
  `dosage` varchar(200) NOT NULL,
  `side_effects` varchar(200) NOT NULL,
  `created_on` date NOT NULL,
  `updatedon` date NOT NULL,
  `image` varchar(100) NOT NULL,
  `company_id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_supplier_med`
--

INSERT INTO `supplier_supplier_med` (`medicineid`, `medicinename`, `batchno`, `mfg_date`, `expiry`, `price_per_unit`, `description`, `dosage`, `side_effects`, `created_on`, `updatedon`, `image`, `company_id`, `supplier_id`) VALUES
(1, 'Metformine', 897654678, '2021-04-01', '2021-04-11', '2.00', 'Tab contains metformin, which belongs to the biguanide group of medicines used to treat type 2 diabetes mellitus (also called known as \'non-insulin dependent diabetes\').', 'Swallow as whole with water', 'Bleeding ,Indigestion ,Hives, Breathing difficulty ,Runny nose ,Itching', '2021-04-10', '2021-04-10', 'images/download_4.jpg', 1, 12);

-- --------------------------------------------------------

--
-- Table structure for table `supplier_s_invoice`
--

CREATE TABLE `supplier_s_invoice` (
  `invoiceid` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `amt_payable` decimal(10,2) NOT NULL,
  `amt_paid` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `paymentmode` varchar(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_s_invoice`
--

INSERT INTO `supplier_s_invoice` (`invoiceid`, `customer_name`, `amt_payable`, `amt_paid`, `balance`, `paymentmode`, `date`, `supplier_id`) VALUES
(1, 'Store_admin', '4.00', '0.00', '4.00', 'Card', '2021-04-10', 12),
(2, 'Store_admin', '4.00', '0.00', '4.00', 'Card', '2021-04-10', 12),
(3, 'Store_admin', '4.00', '0.00', '4.00', 'Card', '2021-04-10', 12),
(4, 'Store_admin', '4.00', '0.00', '4.00', 'Card', '2021-04-10', 12),
(5, 'Store_admin', '4.00', '0.00', '4.00', 'Card', '2021-04-10', 12),
(6, 'Store_admin', '4.00', '0.00', '4.00', 'Card', '2021-04-10', 12),
(7, 'Store_admin', '4.00', '0.00', '4.00', 'Card', '2021-04-10', 12),
(8, 'Store_admin', '2000.00', '0.00', '2000.00', 'Card', '2021-04-10', 12),
(9, 'Store_admin', '8.00', '0.00', '8.00', 'Card', '2021-04-10', 12),
(10, 'Store_admin', '6.00', '0.00', '6.00', 'Card', '2021-04-10', 12);

-- --------------------------------------------------------

--
-- Table structure for table `user_userdetails`
--

CREATE TABLE `user_userdetails` (
  `id` int(11) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `addressline1` varchar(30) NOT NULL,
  `addressline2` varchar(30) NOT NULL,
  `district` varchar(12) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `landmark` varchar(30) NOT NULL,
  `gender_id` int(11) NOT NULL,
  `userid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_userdetails`
--

INSERT INTO `user_userdetails` (`id`, `firstname`, `lastname`, `phone`, `addressline1`, `addressline2`, `district`, `pincode`, `landmark`, `gender_id`, `userid_id`) VALUES
(2, 'Peter', 'Peter', 9989569895, '123/45', 'XYZ villa', 'Ernakulam', '673456', 'MDYRA ground north', 1, 9);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `common_cart`
--
ALTER TABLE `common_cart`
  ADD PRIMARY KEY (`cartid`),
  ADD KEY `common_cart_medicineid_id_17ee88fd_fk_head_medicine_medicineid` (`medicineid_id`),
  ADD KEY `common_cart_userid_id_6ef20ba0_fk_common_login_userid` (`userid_id`);

--
-- Indexes for table `common_cart_item`
--
ALTER TABLE `common_cart_item`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `common_gender`
--
ALTER TABLE `common_gender`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `common_invoice`
--
ALTER TABLE `common_invoice`
  ADD PRIMARY KEY (`invoiceid`),
  ADD KEY `common_invoice_userid_id_19aecc0a_fk_common_login_userid` (`userid_id`);

--
-- Indexes for table `common_login`
--
ALTER TABLE `common_login`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `common_sales`
--
ALTER TABLE `common_sales`
  ADD PRIMARY KEY (`salesid`),
  ADD KEY `common_sales_invoiceid_id_4b04f662_fk_common_invoice_invoiceid` (`invoiceid_id`),
  ADD KEY `common_sales_medicineid_id_f693bd2b_fk_head_medicine_medicineid` (`medicineid_id`),
  ADD KEY `common_sales_userid_id_b47ba268_fk_common_login_userid` (`userid_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `head_company`
--
ALTER TABLE `head_company`
  ADD PRIMARY KEY (`companyid`);

--
-- Indexes for table `head_medicine`
--
ALTER TABLE `head_medicine`
  ADD PRIMARY KEY (`medicineid`),
  ADD KEY `head_medicine_company_id_fb4fb78b_fk_head_company_companyid` (`company_id`);

--
-- Indexes for table `staff_lowstock`
--
ALTER TABLE `staff_lowstock`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_lowstock_cid_id_7da95b6b_fk_head_company_companyid` (`cid_id`),
  ADD KEY `staff_lowstock_mid_id_0f4d0df2_fk_head_medicine_medicineid` (`mid_id`);

--
-- Indexes for table `staff_staffdetails`
--
ALTER TABLE `staff_staffdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_staffdetails_gender_id_9a441966_fk_common_gender_id` (`gender_id`),
  ADD KEY `staff_staffdetails_staffid_id_22bae02f_fk_common_login_userid` (`staffid_id`);

--
-- Indexes for table `supplier_sales_supplier`
--
ALTER TABLE `supplier_sales_supplier`
  ADD PRIMARY KEY (`salesid`),
  ADD KEY `supplier_sales_suppl_invoiceid_id_16d873ce_fk_supplier_` (`invoiceid_id`),
  ADD KEY `supplier_sales_suppl_supplier_id_b8891c2e_fk_common_lo` (`supplier_id`),
  ADD KEY `supplier_sales_suppl_medicineid_id_e0d5b8c8_fk_supplier_` (`medicineid_id`);

--
-- Indexes for table `supplier_supplier`
--
ALTER TABLE `supplier_supplier`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_supplier_userid_id_efc847f2_fk_common_login_userid` (`userid_id`);

--
-- Indexes for table `supplier_supplier_med`
--
ALTER TABLE `supplier_supplier_med`
  ADD PRIMARY KEY (`medicineid`),
  ADD KEY `supplier_supplier_me_company_id_cdac7d73_fk_head_comp` (`company_id`),
  ADD KEY `supplier_supplier_me_supplier_id_66b58edc_fk_common_lo` (`supplier_id`);

--
-- Indexes for table `supplier_s_invoice`
--
ALTER TABLE `supplier_s_invoice`
  ADD PRIMARY KEY (`invoiceid`),
  ADD KEY `supplier_s_invoice_supplier_id_531dc5bc_fk_common_login_userid` (`supplier_id`);

--
-- Indexes for table `user_userdetails`
--
ALTER TABLE `user_userdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_userdetails_gender_id_78f70a02_fk_common_gender_id` (`gender_id`),
  ADD KEY `user_userdetails_userid_id_556ee8d3_fk_common_login_userid` (`userid_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `common_cart`
--
ALTER TABLE `common_cart`
  MODIFY `cartid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `common_cart_item`
--
ALTER TABLE `common_cart_item`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `common_gender`
--
ALTER TABLE `common_gender`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `common_invoice`
--
ALTER TABLE `common_invoice`
  MODIFY `invoiceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `common_login`
--
ALTER TABLE `common_login`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `common_sales`
--
ALTER TABLE `common_sales`
  MODIFY `salesid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `head_company`
--
ALTER TABLE `head_company`
  MODIFY `companyid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `head_medicine`
--
ALTER TABLE `head_medicine`
  MODIFY `medicineid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `staff_lowstock`
--
ALTER TABLE `staff_lowstock`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `staff_staffdetails`
--
ALTER TABLE `staff_staffdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `supplier_sales_supplier`
--
ALTER TABLE `supplier_sales_supplier`
  MODIFY `salesid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `supplier_supplier`
--
ALTER TABLE `supplier_supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `supplier_supplier_med`
--
ALTER TABLE `supplier_supplier_med`
  MODIFY `medicineid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `supplier_s_invoice`
--
ALTER TABLE `supplier_s_invoice`
  MODIFY `invoiceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_userdetails`
--
ALTER TABLE `user_userdetails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `common_cart`
--
ALTER TABLE `common_cart`
  ADD CONSTRAINT `common_cart_medicineid_id_17ee88fd_fk_head_medicine_medicineid` FOREIGN KEY (`medicineid_id`) REFERENCES `head_medicine` (`medicineid`),
  ADD CONSTRAINT `common_cart_userid_id_6ef20ba0_fk_common_login_userid` FOREIGN KEY (`userid_id`) REFERENCES `common_login` (`userid`);

--
-- Constraints for table `common_invoice`
--
ALTER TABLE `common_invoice`
  ADD CONSTRAINT `common_invoice_userid_id_19aecc0a_fk_common_login_userid` FOREIGN KEY (`userid_id`) REFERENCES `common_login` (`userid`);

--
-- Constraints for table `common_sales`
--
ALTER TABLE `common_sales`
  ADD CONSTRAINT `common_sales_invoiceid_id_4b04f662_fk_common_invoice_invoiceid` FOREIGN KEY (`invoiceid_id`) REFERENCES `common_invoice` (`invoiceid`),
  ADD CONSTRAINT `common_sales_medicineid_id_f693bd2b_fk_head_medicine_medicineid` FOREIGN KEY (`medicineid_id`) REFERENCES `head_medicine` (`medicineid`),
  ADD CONSTRAINT `common_sales_userid_id_b47ba268_fk_common_login_userid` FOREIGN KEY (`userid_id`) REFERENCES `common_login` (`userid`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `head_medicine`
--
ALTER TABLE `head_medicine`
  ADD CONSTRAINT `head_medicine_company_id_fb4fb78b_fk_head_company_companyid` FOREIGN KEY (`company_id`) REFERENCES `head_company` (`companyid`);

--
-- Constraints for table `staff_lowstock`
--
ALTER TABLE `staff_lowstock`
  ADD CONSTRAINT `staff_lowstock_cid_id_7da95b6b_fk_head_company_companyid` FOREIGN KEY (`cid_id`) REFERENCES `head_company` (`companyid`),
  ADD CONSTRAINT `staff_lowstock_mid_id_0f4d0df2_fk_head_medicine_medicineid` FOREIGN KEY (`mid_id`) REFERENCES `head_medicine` (`medicineid`);

--
-- Constraints for table `staff_staffdetails`
--
ALTER TABLE `staff_staffdetails`
  ADD CONSTRAINT `staff_staffdetails_gender_id_9a441966_fk_common_gender_id` FOREIGN KEY (`gender_id`) REFERENCES `common_gender` (`id`),
  ADD CONSTRAINT `staff_staffdetails_staffid_id_22bae02f_fk_common_login_userid` FOREIGN KEY (`staffid_id`) REFERENCES `common_login` (`userid`);

--
-- Constraints for table `supplier_sales_supplier`
--
ALTER TABLE `supplier_sales_supplier`
  ADD CONSTRAINT `supplier_sales_suppl_invoiceid_id_16d873ce_fk_supplier_` FOREIGN KEY (`invoiceid_id`) REFERENCES `supplier_s_invoice` (`invoiceid`),
  ADD CONSTRAINT `supplier_sales_suppl_medicineid_id_e0d5b8c8_fk_supplier_` FOREIGN KEY (`medicineid_id`) REFERENCES `supplier_supplier_med` (`medicineid`),
  ADD CONSTRAINT `supplier_sales_suppl_supplier_id_b8891c2e_fk_common_lo` FOREIGN KEY (`supplier_id`) REFERENCES `common_login` (`userid`);

--
-- Constraints for table `supplier_supplier`
--
ALTER TABLE `supplier_supplier`
  ADD CONSTRAINT `supplier_supplier_userid_id_efc847f2_fk_common_login_userid` FOREIGN KEY (`userid_id`) REFERENCES `common_login` (`userid`);

--
-- Constraints for table `supplier_supplier_med`
--
ALTER TABLE `supplier_supplier_med`
  ADD CONSTRAINT `supplier_supplier_me_company_id_cdac7d73_fk_head_comp` FOREIGN KEY (`company_id`) REFERENCES `head_company` (`companyid`),
  ADD CONSTRAINT `supplier_supplier_me_supplier_id_66b58edc_fk_common_lo` FOREIGN KEY (`supplier_id`) REFERENCES `common_login` (`userid`);

--
-- Constraints for table `supplier_s_invoice`
--
ALTER TABLE `supplier_s_invoice`
  ADD CONSTRAINT `supplier_s_invoice_supplier_id_531dc5bc_fk_common_login_userid` FOREIGN KEY (`supplier_id`) REFERENCES `common_login` (`userid`);

--
-- Constraints for table `user_userdetails`
--
ALTER TABLE `user_userdetails`
  ADD CONSTRAINT `user_userdetails_gender_id_78f70a02_fk_common_gender_id` FOREIGN KEY (`gender_id`) REFERENCES `common_gender` (`id`),
  ADD CONSTRAINT `user_userdetails_userid_id_556ee8d3_fk_common_login_userid` FOREIGN KEY (`userid_id`) REFERENCES `common_login` (`userid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
