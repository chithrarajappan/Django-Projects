from django.urls import path
from.import views

urlpatterns = [
            path('userhome',views.userhome,name="userhome"),
            path('search_medicne_user',views.search_medicne_user,name="search_medicne_user"),
            path('user_medicine_view',views.user_medicine_view,name="user_medicine_view"),
            path('med_detail/<int:medicineid>',views.med_detail,name="med_detail"),
            path('useradditem',views.useradditem,name="useradditem"),
            path('useraddnewmed',views.useraddnewmed,name="useraddnewmed"),
            path('placeorder',views.placeorder,name="placeorder"),
            path('userremovefromcart/<int:medicineid>',views.userremovefromcart,name="userremovefromcart"),
            path('userremoveitem',views.userremoveitem,name="userremoveitem"),
            path('userorder',views.userorder,name="userorder"),
            path('userdetails',views.mydetails,name="mydetails"),
            path('usrmakepayment',views.usrmakepayment,name="usrmakepayment"),
path('usersuccess',views.usersuccess,name="usersuccess"),
             ]

