from django.shortcuts import render
from head.models import company,medicine
from common.models import cart,cart_item,invoice,Login,sales
from user.models import UserDetails
from decimal import *
from datetime import date,datetime
from django.db.models import Sum
from django.db.models import Q
import math
# Create your views here.

def user_medicine_view(request):
    medicines = medicine.objects.all()
    return render(request, "user/medicine.html", {'medicines': medicines})

def userhome(request):
	medicines = medicine.objects.all()
	return render(request, "user/medicine.html",{'medicines': medicines})

def search_medicne_user(request):
	if request.POST:
		if request.POST['search']:
			item=request.POST.get("search")
			medicines= medicine.objects.filter(Q(medicinename__icontains=item))
			if medicines:
				medicines= medicine.objects.filter(Q(medicinename__icontains=item))
				companies=company.objects.all()
				return render(request,"user/medicine.html",{'companies':companies,'medicines':medicines})
			else:
				msg="ERROR : Medicine Not Found !!"
				medicines=medicine.objects.all()
				return render(request,"user/medicine.html",{'msg':msg,'medicines':medicines})

	medicines=medicine.objects.all()
	return render(request,"user/medicine.html",{'medicines':medicines})

def med_detail(request,medicineid):
    medicines = medicine.objects.filter(medicineid=medicineid)
    return render(request, "user/med_detail.html", {'medicines': medicines})

def useradditem(request):
	if request.POST:
		mid=request.POST.get("medcineid")
		med=medicine.objects.get(medicineid=mid)
		id=request.session['userid']
		q=int(request.POST.get("quantity"))
		if med.quantity<q:
			msg="Requested quantity not available!!"
			medicines=medicine.objects.filter(medicineid=mid)
			return render(request,"user/med_detail.html",{'medicines':medicines,'msg':msg})
		price=Decimal(med.price_per_unit)
		amt=q*price
		tdate=date.today()
		# newq=med.quantity-q
		# newsold=med.sold+q
		# medicine.objects.filter(medicineid=mid).update(quantity=newq,sold=newsold)
		if invoice.objects.all():
			inv=invoice.objects.latest('invoiceid')
		else:
			inv=1

		if cart_item.objects.filter(userid=request.session['userid'],medicineid=mid):
			c=cart_item.objects.get(userid=request.session['userid'],medicineid=mid)
			q=q+c.quantity
			amt=amt+c.amount
			cart_item.objects.filter(userid=request.session['userid'],medicineid=mid).update(quantity=q,amount=amt)
			cart.objects.filter(userid=request.session['userid'],medicineid=mid).update(quantity=q,amount=amt)
			items=cart.objects.filter(userid=request.session['userid'])
			gtotal=cart.objects.filter(userid=id).aggregate(Sum('amount'))
			return render(request,"user/cart.html",{'items':items,'gtotal':gtotal,'tdate':tdate,'inv':inv})
		cart_item(userid=request.session['userid'],medicineid=mid,quantity=q,amount=amt).save()
		cart(userid=Login.objects.get(userid=id),medicineid=med,quantity=q,amount=amt).save()
		gtotal=cart.objects.filter(userid=id).aggregate(Sum('amount'))
		items=cart.objects.filter(userid=request.session['userid'])
		return render(request,"user/cart.html",{'items':items,'gtotal':gtotal,'tdate':tdate,'inv':inv})

def useraddnewmed(request):
	medicines=medicine.objects.filter(quantity__gt=0)
	return render(request,"user/medicine.html",{'medicines':medicines})

def userremovefromcart(request,medicineid):
	id=request.session['userid']
	medicines=cart.objects.filter(userid=id,medicineid=medicineid)
	return render(request,"user/confirm_item2.html",{'medicines':medicines})

def placeorder(request):
	if request.POST:
		id=request.session['userid']
		c=UserDetails.objects.get(userid_id=id)
		customer=c.firstname
		gtotal=request.POST.get("gtotal")
		amtpaid=0
		balance=math.fabs(Decimal(amtpaid)-Decimal(gtotal))
		mode=request.POST.get("mode")
		invoice(userid=Login.objects.get(userid=id),customer_name=customer,amt_payable=gtotal,amt_paid=amtpaid,
			balance=balance,paymentmode=mode,date=date.today()).save()
		inv=invoice.objects.latest('invoiceid')
		today = date.today()

		obj = cart_item.objects.filter(userid=id)
		for item in obj:
			neworder = sales()
			neworder.invoiceid = inv
			neworder.medicineid = medicine.objects.get(medicineid=item.medicineid)
			neworder.quantity = item.quantity
			neworder.amount = item.amount
			neworder.month=today.month
			neworder.year=today.year
			neworder.date=today
			neworder.userid_id=id
			neworder.save()
		obj2=cart_item.objects.filter(userid=id)
		for item in obj2:
			med=medicine.objects.get(medicineid=item.medicineid)
			qn=med.quantity
			q=qn-item.quantity
			medicine.objects.filter(medicineid=item.medicineid).update(quantity=q)
		cart.objects.filter(userid=id).delete()
		cart_item.objects.filter(userid=id).delete()

		items=sales.objects.filter(invoiceid=inv.invoiceid)
		return render(request,"user/order.html",{'balance':balance,'inv':inv,'items':items})


def userremoveitem(request):
	id=request.session['userid']
	if request.POST:
		mid=request.POST.get("medcineid")
		med=medicine.objects.get(medicineid=mid)
		q=int(request.POST.get("quantity"))
		if med.quantity<q:
			msg="Requested quantity not available!!"
			medicines=cart.objects.filter(userid=id,medicineid=mid)
			return render(request,"user/confirm_item2.html",{'medicines':medicines,'msg':msg})
		price=Decimal(med.price_per_unit)
		amt=q*price
		cart.objects.filter(userid=id,medicineid=mid).update(quantity=q,amount=amt)
		cart_item.objects.filter(userid=id,medicineid=mid).update(quantity=q,amount=amt)
		tdate=date.today()
		if invoice.objects.all():
			inv=invoice.objects.latest('invoiceid')
		else:
			inv=1
		gtotal=cart.objects.filter(userid=id).aggregate(Sum('amount'))
		items=cart.objects.filter(userid=request.session['userid'])
		return render(request,"user/cart.html",{'items':items,'gtotal':gtotal,'tdate':tdate,'inv':inv})


def userorder(request):
	id = request.session['userid']
	orders=sales.objects.filter(userid_id=id)
	return render(request, "user/myorders.html", {'orders': orders})

def mydetails(request):
	id = request.session['userid']
	if request.POST:
		fname = request.POST.get("fname")
		lname = request.POST.get("lname")
		gender = request.POST.get("gender")
		phone = request.POST.get("phone")
		addr1 = request.POST.get("addr_line1")
		addr2 = request.POST.get("addr_line2")
		district = request.POST.get("district")
		landmrk = request.POST.get("landmark")
		pincode = request.POST.get("pincode")
		UserDetails.objects.filter(userid_id=id).update(firstname=fname, lastname=lname, phone=phone, addressline1=addr1, addressline2=addr2,
					 district=district, pincode=pincode, landmark=landmrk)
	users = UserDetails.objects.filter(userid_id=id)
	return render(request, "user/mydetails.html", {'users': users})


def usrmakepayment(request):
	inv=request.POST.get('inv')
	amt=invoice.objects.get(invoiceid=inv)
	items = sales.objects.filter(invoiceid=inv)
	return render(request, 'user/userpayment.html', {'items': items,'amt':amt})


def usersuccess(request):
	inv=invoice.objects.latest('invoiceid')
	items=sales.objects.filter(invoiceid=inv.invoiceid)
	return render(request, 'user/success.html', {'items': items})




