from django.db import models
from common.models import Gender,Login

# Create your models here.

class UserDetails(models.Model):
    userid=models.ForeignKey(Login,on_delete=models.CASCADE)
    firstname = models.CharField(max_length=20)
    lastname = models.CharField(max_length=20)
    gender = models.ForeignKey(Gender,on_delete=models.CASCADE)
    phone = models.BigIntegerField()
    addressline1 = models.CharField(max_length=30)
    addressline2 = models.CharField(max_length=30)
    district = models.CharField(max_length=12)
    pincode = models.CharField(max_length=6)
    landmark = models.CharField(max_length=30)

