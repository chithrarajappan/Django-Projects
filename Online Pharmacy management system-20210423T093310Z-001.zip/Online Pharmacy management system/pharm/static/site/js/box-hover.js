$(document).ready(function(){
	$(".img-box").hover(function(){
		$(this).addClass("alt");
	}, function(){
		$(this).removeClass("alt");
	});
});