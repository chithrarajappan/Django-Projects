from django.db import models
from common.models import Login
from head.models import company,medicine


# Create your models here.

class Supplier(models.Model):
    userid = models.ForeignKey(Login, on_delete=models.CASCADE)
    sname = models.CharField(max_length=20)
    phone = models.BigIntegerField()
    addressline1 = models.CharField(max_length=30)
    addressline2 = models.CharField(max_length=30)
    district = models.CharField(max_length=12)
    pincode = models.CharField(max_length=6)
    status = models.IntegerField(default=0) #0-pending 1=approved 2=rejected


class Supplier_med(models.Model):
    supplier=models.ForeignKey(Login,on_delete=models.CASCADE)
    medicineid = models.AutoField(primary_key='True')
    company = models.ForeignKey(company, on_delete=models.CASCADE)
    medicinename = models.CharField(max_length=100)
    batchno = models.IntegerField()
    mfg_date = models.DateField()
    expiry = models.DateField()
    price_per_unit = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.CharField(max_length=200)
    dosage = models.CharField(max_length=200)
    side_effects = models.CharField(max_length=200)
    created_on = models.DateField()
    updatedon = models.DateField()
    image = models.ImageField(upload_to='images')

class s_invoice(models.Model):
    supplier=models.ForeignKey(Login,on_delete=models.CASCADE)
    invoiceid=models.AutoField(primary_key=True)
    customer_name=models.CharField(max_length=50)
    amt_payable=models.DecimalField(max_digits=10, decimal_places=2)
    amt_paid=models.DecimalField(max_digits=10, decimal_places=2)
    balance=models.DecimalField(max_digits=10, decimal_places=2)
    paymentmode=models.CharField(max_length=10)
    date=models.CharField(max_length=50)

class sales_supplier(models.Model):
    supplier = models.ForeignKey(Login, on_delete=models.CASCADE)
    salesid=models.AutoField(primary_key=True)
    invoiceid=models.ForeignKey(s_invoice,on_delete=models.CASCADE)
    medicineid=models.ForeignKey(Supplier_med,on_delete=models.CASCADE)
    quantity=models.IntegerField()
    amount=models.DecimalField(max_digits=10, decimal_places=2)
    month=models.CharField(max_length=5)
    year=models.IntegerField()
    date=models.CharField(max_length=50,default='2020-03-21')


