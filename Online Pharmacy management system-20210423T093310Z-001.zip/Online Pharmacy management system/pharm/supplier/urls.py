from django.urls import path
from.import views

urlpatterns = [
        path('supplierhome', views.supplierhome, name='supplierhome'),
        path('addmedicine', views.addmedicine, name='addmedicine'),
        path('viewporder', views.viewporder, name='viewporder'),
path('viewinvoice', views.viewinvoice, name='viewinvoice'),


        ]