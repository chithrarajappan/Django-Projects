from django.shortcuts import render
from head.models import company
from supplier.models import Supplier_med,Supplier,sales_supplier,s_invoice
from datetime import date,datetime
from common.models import Login

# Create your views here.

def supplierhome(request):
    return render(request, 'supplier/home.html')

def addmedicine(request):
    id = request.session['userid']
    if request.POST:

        compid = request.POST.get("company")
        c = company.objects.get(companyid=compid)
        medcn = request.POST.get("medicine")
        batno = request.POST.get("batch")
        mfgd = request.POST.get("mfg")
        expd = request.POST.get("exp")
        quant = request.POST.get("quantity")
        price = request.POST.get("price")
        des = request.POST.get("des")
        dose = request.POST.get("dose")
        effect = request.POST.get("seffect")
        store_loc = request.POST.get("loc")
        im = request.FILES['img']
        today = date.today()
        if Supplier_med.objects.filter(batchno=batno, medicinename=medcn,supplier=id):
            m = Supplier_med.objects.get(batchno=batno, medicinename=medcn,supplier=id)
            q = m.quantity + Decimal(quant)
            Supplier_med.objects.filter(batchno=batno, medicinename=medcn,supplier=id).update(quantity=q, price_per_unit=price,
                                                                              company=c, medicinename=medcn,
                                                                              batchno=batno, updatedon=today)
        else:
            Supplier_med(company=c, medicinename=medcn, batchno=batno, mfg_date=mfgd, expiry=expd,
                     price_per_unit=price, description=des, dosage=dose, side_effects=effect, created_on=today,
                     updatedon=today,  image=im,supplier=Login.objects.get(userid=id)).save()
        msg = "Successfully Added Medicine"
        companies = company.objects.all()
        medicines = Supplier_med.objects.filter(supplier=id)
        return render(request, 'supplier/addmedicine.html', {'companies': companies, 'medicines': medicines, 'msg': msg})
    companies = company.objects.all()
    medicines = Supplier_med.objects.filter(supplier=id)
    return render(request, 'supplier/addmedicine.html',{'companies': companies, 'medicines': medicines})


def viewporder(request):
    orders=sales_supplier.objects.filter(supplier=request.session['userid'])
    return render(request, 'supplier/orders_supplier.html', {'orders': orders})

def viewinvoice(request):
    orders=s_invoice.objects.filter(supplier=request.session['userid'])
    return render(request, 'supplier/invoice_supplier.html', {'orders': orders})


