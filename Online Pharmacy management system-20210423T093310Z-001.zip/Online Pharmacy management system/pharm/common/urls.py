from django.urls import path
from.import views

urlpatterns = [
        path('', views.index, name="index"),
        path('about', views.about, name="about"),
        path('logout', views.logout1, name="logout1"),
        path('contact', views.contact, name="contact"),
        path('login', views.alllogin, name="alllogin"),
        path('login_action', views.login_action, name="login_action"),
        path('stafflogin', views.stafflogin, name="stafflogin"),
        path('user_registration', views.usrregistration, name="usrregistration"),
        path('supregistration', views.supregistration, name="supregistration"),
        path('register', views.register_user, name="register_user"),
        path('staff_reg', views.staff_reg, name="staff_reg"),

]