from django.shortcuts import render
from common.models import Gender,Login
from user.models import UserDetails
from staff.models import StaffDetails
from supplier.models import Supplier
from head.models import medicine
from common.models import Login
from datetime import date,datetime
from datetime import timedelta
from staff.models import lowstock
# Create your views here.

def index(request):
    return render(request, "common/index.html")
def contact(request):
    return render(request, "common/contact.html")
def about(request):
    return render(request, "common/about.html")
def alllogin(request):
    return render(request, "common/login.html")

def login_action(request):
    if request.POST:
        username=request.POST.get("username")
        password=request.POST.get("password")
        if Login.objects.filter(username=username,password=password).exists():
            loginuser=Login.objects.get(username=username,password=password)
            request.session['userid'] = loginuser.userid
            request.session['user_name'] = loginuser.username
            if loginuser.role == 0:
                low=lowstock.objects.all()
                return render(request, 'head/admin_panel.html',{'low':low})

            if loginuser.role == 1:
                e=0
                s=0
                today=date.today()
                nextm=today+timedelta(days=30)
                exp=medicine.objects.filter(expiry__month=nextm.month)
                if exp:
                    e=1
                stck=medicine.objects.filter(quantity__lte=10)
                if stck:
                    s=1
                return render(request,"staff/staff_panel.html",{'exp':exp,'stck':stck,'e':e,'s':s})

            if loginuser.role == 2:
                medicines = medicine.objects.all()
                return render(request,"user/medicine.html",{'medicines':medicines})
            if loginuser.role == 3:
                s=Supplier.objects.get(userid=loginuser.userid)
                if s.status == 0:
                    msg = "Your account is Waiting for admin approval"
                    return render(request, 'common/error.html', {'msg': msg})
                if s.status == 2:
                    msg = "Your request has been Rejected by Admin"
                    return render(request, 'common/error.html', {'msg': msg})
                return render(request,"supplier/home.html")
        else:
            msg = "Invalid Account"
            return render(request, 'common/error.html', {'msg': msg})


def stafflogin(request):
    return render(request, "common/stafflogin.html")

def staff_reg(request):
    if request.POST:
        fname = request.POST.get("fname")
        lname = request.POST.get("lname")
        gender = request.POST.get("gender")
        phone = request.POST.get("phone")
        staffid = request.POST.get("staffid")
        user = request.POST.get("username")
        pswd = request.POST.get("password")
        obj=Login.objects.filter(username=user)
        if obj:
            msg="Username already exists"
            return render(request, "common/error.html", {'msg': msg})
        l = Login()
        l.username = user
        l.password = pswd
        l.role = 1
        l.save()
        StaffDetails(staffid=l, firstname=fname, lastname=lname, phone=phone,gender=Gender.objects.get(id=gender),
                     employeeID=staffid,email=user).save()
        msg = "Successfully Registered"
        return render(request, "common/stafflogin.html", {'msg': msg})
    gender = Gender.objects.all()
    return render(request, "common/staffregistration.html",{'gender':gender})

def usrregistration(request):
    gender=Gender.objects.all()
    return render(request, "common/user_registration.html",{'gender':gender})

def register_user(request):
    if request.POST:
        fname=request.POST.get("fname")
        lname = request.POST.get("lname")
        gender = request.POST.get("gender")
        phone = request.POST.get("phone")
        addr1 = request.POST.get("addr_line1")
        addr2 = request.POST.get("addr_line2")
        district = request.POST.get("district")
        landmrk = request.POST.get("landmark")
        pincode = request.POST.get("pincode")
        user=request.POST.get("username")
        pswd=request.POST.get("password")

        l=Login()
        l.username = user
        l.password = pswd
        l.role = 2
        l.save()
        UserDetails(userid=l,firstname=fname,lastname=lname,phone=phone,addressline1=addr1,addressline2=addr2,
                    gender=Gender.objects.get(id=gender),district=district,pincode=pincode,landmark=landmrk).save()
        msg="Successfully Registered"
        return render(request,"common/login.html",{'msg':msg})


def supregistration(request):
    if request.POST:
        fname=request.POST.get("fname")
        phone = request.POST.get("phone")
        addr1 = request.POST.get("addr_line1")
        addr2 = request.POST.get("addr_line2")
        district = request.POST.get("district")
        pincode = request.POST.get("pincode")
        user=request.POST.get("username")
        pswd=request.POST.get("password")

        l=Login()
        l.username = user
        l.password = pswd
        l.role = 3
        l.save()
        Supplier(userid=l,sname=fname,phone=phone,addressline1=addr1,addressline2=addr2,district=district,pincode=pincode).save()
        msg="Successfully Registered, You need admin approval to login. Thank you"
        return render(request,"common/login.html",{'msg':msg})
    return render(request, "common/supplier_reg.html")




from django.contrib.auth import logout
def logout1(request):
    logout(request)
    return render(request, "common/index.html")

