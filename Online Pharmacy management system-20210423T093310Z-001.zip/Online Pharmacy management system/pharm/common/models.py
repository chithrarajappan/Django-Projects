from django.db import models
from head.models import  medicine
# Create your models here.

class Login(models.Model):
    userid=models.AutoField(primary_key=True)
    username=models.CharField(max_length=25)
    password=models.CharField(max_length=10)
    role=models.IntegerField(default=1) #admin/head=0, pharmacist/staff=1, user=2,supplier-3

class Gender(models.Model):
    gender=models.CharField(max_length=7)

class cart(models.Model):
	cartid=models.AutoField(primary_key='True')
	userid=models.ForeignKey(Login,on_delete=models.CASCADE)
	medicineid=models.ForeignKey(medicine,on_delete=models.CASCADE)
	quantity=models.IntegerField()
	amount=models.DecimalField(max_digits=10, decimal_places=2)

class cart_item(models.Model):
	pid=models.AutoField(primary_key='True')
	userid=models.IntegerField()
	medicineid=models.IntegerField()
	quantity=models.IntegerField()
	amount=models.DecimalField(max_digits=10, decimal_places=2)

class invoice(models.Model):
	invoiceid=models.AutoField(primary_key=True)
	userid=models.ForeignKey(Login,on_delete=models.CASCADE)
	customer_name=models.CharField(max_length=50)
	amt_payable=models.DecimalField(max_digits=10, decimal_places=2)
	amt_paid=models.DecimalField(max_digits=10, decimal_places=2)
	balance=models.DecimalField(max_digits=10, decimal_places=2)
	paymentmode=models.CharField(max_length=10)
	date=models.CharField(max_length=50)


class sales(models.Model):
	salesid=models.AutoField(primary_key=True)
	invoiceid=models.ForeignKey(invoice,on_delete=models.CASCADE)
	medicineid=models.ForeignKey(medicine,on_delete=models.CASCADE)
	quantity=models.IntegerField()
	amount=models.DecimalField(max_digits=10, decimal_places=2)
	month=models.CharField(max_length=5)
	year=models.IntegerField()
	date=models.CharField(max_length=50,default='2020-03-21')
	userid = models.ForeignKey(Login, on_delete=models.CASCADE)

