from django.urls import path
from.import views

urlpatterns = [
    path('adminhome',views.adminhome, name='adminhome'),
    path('manage_supplier', views.manage_supplier, name='manage_supplier'),
    path('company',views.manage_company, name='manage_company'),
    path('editcmpny/<int:companyid>',views.editcmpny, name='editcmpny'),
    path('updatecmpny/',views.updatecmpny, name='updatecmpny'),
    path('deletecmpny/<int:companyid>',views.deletecmpny, name='deletecmpny'),
    path('details/<int:id>',views.details, name='details'),
    path('medicine',views.manage_medicine, name='manage_medicine'),
    path('editmedicn/<int:medicineid>',views.editmedicn, name='editmedicn'),
    path('edit_medicines/',views.edit_medicines, name='edit_medicines'),
    path('deletemedicn/<int:medicineid>',views.deletemedicn, name='deletemedicn'),
    path('search_medicines/',views.search_medicines, name='search_medicines'),
    path('purchase_medicine/',views.purchase_medicine, name='purchase_medicine'),
    path('purchase_orders/',views.purchase_orders, name='purchase_orders'),
    path('search_medicines_purchase/',views.search_medicines_purchase, name='search_medicines_purchase'),
    path('placepurchase/<int:medicineid>',views.placepurchase, name='placepurchase'),
    path('confirmorder',views.confirmorder, name='confirmorder'),
    path('success',views.success, name='success'),

]

