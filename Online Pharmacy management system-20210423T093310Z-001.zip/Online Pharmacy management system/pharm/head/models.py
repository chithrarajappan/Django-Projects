from django.db import models

# Create your models here.
class company(models.Model):
    companyid = models.AutoField(primary_key='True')
    companyname = models.CharField(max_length=40)

class medicine(models.Model):
	medicineid=models.AutoField(primary_key='True')
	company=models.ForeignKey(company,on_delete=models.CASCADE)
	medicinename = models.CharField(max_length=100)
	batchno=models.IntegerField()
	mfg_date=models.DateField()
	expiry=models.DateField()
	price_per_unit=models.DecimalField(max_digits=10, decimal_places=2)
	description= models.CharField(max_length=200)
	dosage = models.CharField(max_length=200)
	side_effects=models.CharField(max_length=200)
	created_on = models.DateField()
	updatedon = models.DateField()
	quantity = models.IntegerField(default=0)
	storage_location= models.CharField(max_length=20)
	image = models.ImageField(upload_to='images')





