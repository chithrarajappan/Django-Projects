from django.apps import AppConfig


class HeadConfig(AppConfig):
    name = 'head'
