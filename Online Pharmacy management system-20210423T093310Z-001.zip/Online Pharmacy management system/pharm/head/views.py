from django.shortcuts import render
from head.models import company,medicine
from supplier.models import Supplier,Supplier_med,s_invoice,sales_supplier
from common.models import Login
from datetime import date,datetime
from django.db.models import Q
from decimal import *
from datetime import date,datetime
from django.db.models import Sum
from staff.models import lowstock
# Create your views here.


def adminhome(request):
	low = lowstock.objects.all()
	return render(request,'head/admin_panel.html',{'low':low})

#company code
def manage_company(request):
    if request.POST:
        compname = request.POST.get("companyname")
        company(companyname=compname).save()
    companies = company.objects.all()
    return render(request, "head/company.html", {'companies': companies})


def manage_supplier(request):
	newsupp=Supplier.objects.filter(status=0)
	suppliers = Supplier.objects.filter(status=1)
	return render(request, "head/supplier.html", {'suppliers': suppliers,'newsupp':newsupp})

def editcmpny(request,companyid):
	c=company.objects.filter(companyid=companyid)
	return render(request,"head/editcompany.html",{'c':c})

def updatecmpny(request):
	if request.POST:
		cid=request.POST.get("compid")
		cname=request.POST.get("compname")
		company.objects.filter(companyid=cid).update(companyname=cname)
		msg="Company Detail Updated !!"
		companies=company.objects.all()
		return render(request,"head/company.html",{'companies':companies,'msg':msg})

def deletecmpny(request,companyid):
	company.objects.filter(companyid=companyid).delete()
	msg="Successfully Removed Company"
	companies=company.objects.all()
	return render(request,"head/company.html",{'companies':companies,'msg':msg})

#medicine codes

def manage_medicine(request):
	if request.POST:
		compid=request.POST.get("company")
		c=company.objects.get(companyid=compid)
		medcn=request.POST.get("medicine")
		batno=request.POST.get("batch")
		mfgd=request.POST.get("mfg")
		expd=request.POST.get("exp")
		quant=request.POST.get("quantity")
		price=request.POST.get("price")
		des=request.POST.get("des")
		dose=request.POST.get("dose")
		effect=request.POST.get("seffect")
		store_loc = request.POST.get("loc")
		im = request.FILES['img']
		today = date.today()
		if medicine.objects.filter(batchno=batno,medicinename=medcn):
			m=medicine.objects.get(batchno=batno,medicinename=medcn)
			q=m.quantity+Decimal(quant)
			medicine.objects.filter(batchno=batno,medicinename=medcn).update(quantity=q,price_per_unit=price,company=c,medicinename=medcn,batchno=batno,updatedon=today)
		else:
			medicine(company=c,medicinename=medcn,batchno=batno,mfg_date=mfgd,expiry=expd,quantity=quant,price_per_unit=price,description=des,dosage=dose,side_effects=effect,created_on=today,updatedon=today,storage_location=store_loc,image=im).save()
		msg="Successfully Added Medicine"
		companies=company.objects.all()
		medicines=medicine.objects.all()
		return render(request,"head/medicine.html",{'companies':companies,'medicines':medicines,'msg':msg})
	companies=company.objects.all()
	medicines=medicine.objects.all()
	return render(request,"head/medicine.html",{'companies':companies,'medicines':medicines})


def deletemedicn(request,medicineid):
	medicine.objects.filter(medicineid=medicineid).delete()
	msg="Successfully Removed Medicine"
	companies=company.objects.all()
	medicines=medicine.objects.all()
	return render(request,"head/medicine.html",{'companies':companies,'medicines':medicines,'msg':msg})

def edit_medicines(request):
	# if request.session.get('userid') is None:
	# 	errr = 'Login Required'
	# 	errormsg = {'errr': errr}
	# 	return message(request, errormsg)
	if request.POST:
		mid=request.POST.get("medicineid")
		medcn=request.POST.get("medicine")
		batno=request.POST.get("batch")
		quant=request.POST.get("quantity")
		price=request.POST.get("price")
		medicine.objects.filter(medicineid=mid).update(medicinename=medcn,batchno=batno,quantity=quant,price_per_unit=price)
		msg="Successfully Updated !!"
		companies=company.objects.all()
		medicines=medicine.objects.all()
		return render(request,"head/medicine.html",{'companies':companies,'medicines':medicines,'msg':msg})

def editmedicn(request,medicineid):
	medicines=medicine.objects.filter(medicineid=medicineid)
	return render(request,"head/editmedicine.html",{'medicines':medicines})

def search_medicines(request):
	# if request.session.get('userid') is None:
	# 	errr = 'Login Required'
	# 	errormsg = {'errr': errr}
	# 	return message(request, errormsg)
	if request.POST['search']:
		item=request.POST.get("search")
		medicines= medicine.objects.filter(Q(medicinename__icontains=item))
		if medicines:
			medicines= medicine.objects.filter(Q(medicinename__icontains=item))
			companies=company.objects.all()
			return render(request,"head/searchmedicine.html",{'companies':companies,'medicines':medicines})
		else:
			msg="ERROR : Medicine Not Found !!"
			medicines=medicine.objects.all()
			return render(request,"head/searchmedicine.html",{'msg':msg,'medicines':medicines})
	msg="Error : Enter Medicine Name to Search"
	medicines=medicine.objects.all()
	return render(request,"head/searchmedicine.html",{'msg':msg,'medicines':medicines})

def details(request,id):
	if request.POST:
		s = request.POST.get("stat")
		Supplier.objects.filter(id=id).update(status=s)
		return manage_supplier(request)
	supp=Supplier.objects.get(id=id)
	return render(request,"head/approvesupplier.html",{'supp':supp})

def purchase_medicine(request):
	medicines=Supplier_med.objects.all()
	return render(request, "head/purchasemedicine.html", {'medicines': medicines})

def search_medicines_purchase(request):
	# if request.session.get('userid') is None:
	# 	errr = 'Login Required'
	# 	errormsg = {'errr': errr}
	# 	return message(request, errormsg)
	if request.POST['search']:
		item=request.POST.get("search")
		medicines= Supplier_med.objects.filter(Q(medicinename__icontains=item))
		if medicines:
			medicines= Supplier_med.objects.filter(Q(medicinename__icontains=item))
			companies=company.objects.all()
			return render(request,"head/search_med_purchase.html",{'companies':companies,'medicines':medicines})
		else:
			msg="ERROR : Medicine Not Found !!"
			medicines=Supplier_med.objects.all()
			return render(request,"head/search_med_purchase.html",{'msg':msg,'medicines':medicines})
	msg="Error : Enter Medicine Name to Search"
	medicines=Supplier_med.objects.all()
	return render(request,"head/search_med_purchase.html",{'msg':msg,'medicines':medicines})

def placepurchase(request,medicineid):
	medicine=Supplier_med.objects.get(medicineid=medicineid)
	return render(request, "head/selectquantity.html", {'m': medicine})

def confirmorder(request):
	mid=request.POST.get('mid')
	q=int(request.POST.get('quantity'))
	med=Supplier_med.objects.get(medicineid=mid)
	price = Decimal(med.price_per_unit)
	amt = q * price
	tdate = date.today()
	if s_invoice.objects.all():
		inv = s_invoice.objects.latest('invoiceid')
	else:
		inv = 1
	s_invoice(customer_name='Store_admin',supplier=med.supplier,amt_payable=amt,amt_paid=0,balance=amt,paymentmode='Card',date=tdate).save()
	sales_supplier(supplier=med.supplier,invoiceid=inv,medicineid=med,quantity=q,amount=amt,month=tdate.month,year=tdate.year).save()
	items=sales_supplier.objects.latest('salesid')
	return render(request,'head/payment.html',{'items':items})


def success(request):
	items = sales_supplier.objects.latest('salesid')
	return render(request, 'head/success.html',{'items':items})

def purchase_orders(request):
	orders= sales_supplier.objects.all()
	return render(request, 'head/purchase_orders.html', {'orders': orders})





