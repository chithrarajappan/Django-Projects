from django.db import models
from common.models import Gender,Login
from head.models import company,medicine
# Create your models here.
class StaffDetails(models.Model):
    staffid=models.ForeignKey(Login,on_delete=models.CASCADE)
    firstname = models.CharField(max_length=20)
    lastname = models.CharField(max_length=20)
    email = models.CharField(max_length=35)
    gender = models.ForeignKey(Gender,on_delete=models.CASCADE)
    phone = models.BigIntegerField()
    employeeID = models.IntegerField()


class lowstock(models.Model):
    cid=models.ForeignKey(company,on_delete=models.CASCADE)
    mid=models.ForeignKey(medicine,on_delete=models.CASCADE)