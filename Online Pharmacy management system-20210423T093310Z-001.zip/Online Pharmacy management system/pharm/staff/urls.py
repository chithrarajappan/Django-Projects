from django.urls import path
from . import views

urlpatterns = [
     path('staffhome',views.staffhome,name='staffhome'),
     path('medicine_view',views.medicine_view,name='medicine_view'),
     path('search_medicne_phm/',views.search_medicne_phm, name='search_medicne_phm'),
     path('sale/',views.sale, name='sale'),
     path('search/', views.search,name='search'),
     path('confirmitem/<int:medicineid>', views.confirmitem,name='confirmitem'),
     path('additem/', views.additem,name='additem'),
     path('makepayment/', views.makepayment,name='makepayment'),
     path('getinvoice/', views.getinvoice,name='getinvoice'),
     path('removefromcart/<int:medicineid>', views.removefromcart,name='removefromcart'),
     path('addnewmed/', views.addnewmed,name='addnewmed'),
     path('removeitem/', views.removeitem,name='removeitem'),
     path('lowstock/', views.lowstockr,name='lowstockr'),

     ]

