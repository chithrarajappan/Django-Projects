from django.shortcuts import render
from head.models import company,medicine
from django.db.models import Q
from common.models import cart,cart_item,invoice,Login,sales
from staff.models import lowstock
from decimal import *
from datetime import date,datetime
from django.db.models import Sum
from pharm.utils import render_to_pdf
from django.http import HttpResponse
from datetime import timedelta
# Create your views here.

def staffhome(request):
	e = 0
	s = 0
	today = date.today()
	nextm = today + timedelta(days=30)
	exp = medicine.objects.filter(expiry__month=nextm.month)
	if exp:
		e = 1
	stck = medicine.objects.filter(quantity__lte=10)
	if stck:
		s = 1
	return render(request, "staff/staff_panel.html", {'exp': exp, 'stck': stck, 'e': e, 's': s})


def medicine_view(request):
    companies = company.objects.all()
    medicines = medicine.objects.all()
    return render(request, "staff/medicine.html", {'companies': companies, 'medicines': medicines})


def search_medicne_phm(request):
	if request.POST:
		if request.POST['search']:
			item=request.POST.get("search")
			medicines= medicine.objects.filter(Q(medicinename__icontains=item))
			if medicines:
				medicines= medicine.objects.filter(Q(medicinename__icontains=item))
				companies=company.objects.all()
				return render(request,"staff/medicine.html",{'companies':companies,'medicines':medicines})
			else:
				msg="ERROR : Medicine Not Found !!"
				medicines=medicine.objects.all()
				return render(request,"staff/medicine.html",{'msg':msg,'medicines':medicines})
	companies=company.objects.all()
	medicines=medicine.objects.all()
	return render(request,"staff/medicine.html",{'companies':companies,'medicines':medicines})

def sale(request):
	id=request.session['userid']
	cart.objects.filter(userid=id).delete()
	cart_item.objects.filter(userid=id).delete()
	medicines=medicine.objects.filter(quantity__gt=0)
	return render(request,"staff/sale.html",{'medicines':medicines})

def search(request):
	if request.POST:
		if request.POST['search']:
			item=request.POST.get("search")
			medicines= medicine.objects.filter(Q(medicinename__icontains=item))
			count=0
			if medicines:
				medicines= medicine.objects.filter(Q(medicinename__icontains=item))
				count=1
				return render(request,"staff/sale.html",{'medicines':medicines,'count':count})
			else:
				msg="ERROR : Medicine Not Found !!"
				return render(request,"staff/sale.html",{'msg':msg})

def confirmitem(request,medicineid):
	medicines=medicine.objects.filter(medicineid=medicineid)
	return render(request,"staff/confirm_item.html",{'medicines':medicines})


def additem(request):
	if request.POST:
		mid=request.POST.get("medcineid")
		med=medicine.objects.get(medicineid=mid)
		id=request.session['userid']
		q=int(request.POST.get("quantity"))
		if med.quantity<q:
			msg="Requested quantity not available!!"
			medicines=medicine.objects.filter(medicineid=mid)
			return render(request,"staff/confirm_item.html",{'medicines':medicines,'msg':msg})
		price=Decimal(med.price_per_unit)
		amt=q*price
		tdate=date.today()
		# newq=med.quantity-q
		# newsold=med.sold+q
		# medicine.objects.filter(medicineid=mid).update(quantity=newq,sold=newsold)
		if invoice.objects.all():
			inv=invoice.objects.latest('invoiceid')
		else:
			inv=1

		if cart_item.objects.filter(userid=request.session['userid'],medicineid=mid):
			c=cart_item.objects.get(userid=request.session['userid'],medicineid=mid)
			q=q+c.quantity
			amt=amt+c.amount
			cart_item.objects.filter(userid=request.session['userid'],medicineid=mid).update(quantity=q,amount=amt)
			cart.objects.filter(userid=request.session['userid'],medicineid=mid).update(quantity=q,amount=amt)
			items=cart.objects.filter(userid=request.session['userid'])
			gtotal=cart.objects.filter(userid=id).aggregate(Sum('amount'))
			return render(request,"staff/invoice.html",{'items':items,'gtotal':gtotal,'tdate':tdate,'inv':inv})
		cart_item(userid=request.session['userid'],medicineid=mid,quantity=q,amount=amt).save()
		cart(userid=Login.objects.get(userid=id),medicineid=med,quantity=q,amount=amt).save()
		gtotal=cart.objects.filter(userid=id).aggregate(Sum('amount'))
		items=cart.objects.filter(userid=request.session['userid'])
		return render(request,"staff/invoice.html",{'items':items,'gtotal':gtotal,'tdate':tdate,'inv':inv})

def makepayment(request):
	if request.POST:
		id=request.session['userid']
		customer=request.POST.get("patient")
		gtotal=request.POST.get("gtotal")
		amtpaid=request.POST.get("paid")
		balance=Decimal(amtpaid)-Decimal(gtotal)
		mode=request.POST.get("mode")
		invoice(userid=Login.objects.get(userid=id),customer_name=customer,amt_payable=gtotal,amt_paid=amtpaid,
			balance=balance,paymentmode=mode,date=date.today()).save()
		inv=invoice.objects.latest('invoiceid')
		today = date.today()

		obj = cart_item.objects.filter(userid=id)
		for item in obj:
			neworder = sales()
			neworder.invoiceid = inv
			neworder.medicineid = medicine.objects.get(medicineid=item.medicineid)
			neworder.quantity = item.quantity
			neworder.amount = item.amount
			neworder.month=today.month
			neworder.year=today.year
			neworder.date=today
			neworder.userid_id = id
			neworder.save()
		obj2=cart_item.objects.filter(userid=id)
		for item in obj2:
			med=medicine.objects.get(medicineid=item.medicineid)
			qn=med.quantity
			q=qn-item.quantity
			medicine.objects.filter(medicineid=item.medicineid).update(quantity=q)
		cart.objects.filter(userid=id).delete()
		cart_item.objects.filter(userid=id).delete()

		items=sales.objects.filter(invoiceid=inv.invoiceid)
		return render(request,"staff/bill.html",{'balance':balance,'inv':inv,'items':items})


def getinvoice(request,*args, **kwargs):
	inv=invoice.objects.latest('invoiceid')
	items=sales.objects.filter(invoiceid=inv.invoiceid)
	data ={'inv':inv,'items':items}
	pdf = render_to_pdf('pdf/invoice.html', data)
	# return HttpResponse(pdf, content_type='application/pdf')
	response = HttpResponse(pdf,content_type='application/pdf')
	response['Content-Disposition'] = 'attachment'
	return response


def removefromcart(request,medicineid):
	id=request.session['userid']
	medicines=cart.objects.filter(userid=id,medicineid=medicineid)
	return render(request,"staff/confirm_item2.html",{'medicines':medicines})

def addnewmed(request):
	medicines=medicine.objects.filter(quantity__gt=0)
	return render(request,"staff/sale.html",{'medicines':medicines})

def removeitem(request):
	id=request.session['userid']
	if request.POST:
		mid=request.POST.get("medcineid")
		med=medicine.objects.get(medicineid=mid)
		q=int(request.POST.get("quantity"))
		if med.quantity<q:
			msg="Requested quantity not available!!"
			medicines=cart.objects.filter(userid=id,medicineid=mid)
			return render(request,"staff/confirm_item2.html",{'medicines':medicines,'msg':msg})
		price=Decimal(med.price_per_unit)
		amt=q*price
		cart.objects.filter(userid=id,medicineid=mid).update(quantity=q,amount=amt)
		cart_item.objects.filter(userid=id,medicineid=mid).update(quantity=q,amount=amt)
		tdate=date.today()
		if invoice.objects.all():
			inv=invoice.objects.latest('invoiceid')
		else:
			inv=1
		gtotal=cart.objects.filter(userid=id).aggregate(Sum('amount'))
		items=cart.objects.filter(userid=request.session['userid'])
		return render(request,"staff/invoice.html",{'items':items,'gtotal':gtotal,'tdate':tdate,'inv':inv})


def lowstockr(request):
	if request.POST:
		cid=request.POST.get('company')
		mid=request.POST.get('med')
		lowstock(cid=company.objects.get(companyid=cid),mid=medicine.objects.get(medicineid=mid)).save()
	companies=company.objects.all()
	medicines=medicine.objects.filter(quantity__lte=20)
	return render(request, "staff/lowstock.html",{'companies':companies,'medicines':medicines})
