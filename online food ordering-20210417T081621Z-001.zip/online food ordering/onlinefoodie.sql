-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2021 at 08:54 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinefoodie`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminapp_staff`
--

CREATE TABLE `adminapp_staff` (
  `id` int(11) NOT NULL,
  `name` varchar(25) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `staffid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminapp_staff`
--

INSERT INTO `adminapp_staff` (`id`, `name`, `phone`, `staffid_id`) VALUES
(1, 'Staff1', 9989569895, 2);

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add login', 7, 'add_login'),
(26, 'Can change login', 7, 'change_login'),
(27, 'Can delete login', 7, 'delete_login'),
(28, 'Can view login', 7, 'view_login'),
(29, 'Can add staff', 8, 'add_staff'),
(30, 'Can change staff', 8, 'change_staff'),
(31, 'Can delete staff', 8, 'delete_staff'),
(32, 'Can view staff', 8, 'view_staff'),
(33, 'Can add food item', 9, 'add_fooditem'),
(34, 'Can change food item', 9, 'change_fooditem'),
(35, 'Can delete food item', 9, 'delete_fooditem'),
(36, 'Can view food item', 9, 'view_fooditem'),
(37, 'Can add cart_item', 10, 'add_cart_item'),
(38, 'Can change cart_item', 10, 'change_cart_item'),
(39, 'Can delete cart_item', 10, 'delete_cart_item'),
(40, 'Can view cart_item', 10, 'view_cart_item'),
(41, 'Can add coupon', 11, 'add_coupon'),
(42, 'Can change coupon', 11, 'change_coupon'),
(43, 'Can delete coupon', 11, 'delete_coupon'),
(44, 'Can view coupon', 11, 'view_coupon'),
(45, 'Can add order', 12, 'add_order'),
(46, 'Can change order', 12, 'change_order'),
(47, 'Can delete order', 12, 'delete_order'),
(48, 'Can view order', 12, 'view_order'),
(49, 'Can add review', 13, 'add_review'),
(50, 'Can change review', 13, 'change_review'),
(51, 'Can delete review', 13, 'delete_review'),
(52, 'Can view review', 13, 'view_review'),
(53, 'Can add ordered item', 14, 'add_ordereditem'),
(54, 'Can change ordered item', 14, 'change_ordereditem'),
(55, 'Can delete ordered item', 14, 'delete_ordereditem'),
(56, 'Can view ordered item', 14, 'view_ordereditem'),
(57, 'Can add invoice', 15, 'add_invoice'),
(58, 'Can change invoice', 15, 'change_invoice'),
(59, 'Can delete invoice', 15, 'delete_invoice'),
(60, 'Can view invoice', 15, 'view_invoice'),
(61, 'Can add customer', 16, 'add_customer'),
(62, 'Can change customer', 16, 'change_customer'),
(63, 'Can delete customer', 16, 'delete_customer'),
(64, 'Can view customer', 16, 'view_customer'),
(65, 'Can add cart', 17, 'add_cart'),
(66, 'Can change cart', 17, 'change_cart'),
(67, 'Can delete cart', 17, 'delete_cart'),
(68, 'Can view cart', 17, 'view_cart');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_cart`
--

CREATE TABLE `customer_cart` (
  `cartid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `foodid_id` int(11) NOT NULL,
  `userid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_cart_item`
--

CREATE TABLE `customer_cart_item` (
  `pid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `foodid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `requests` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customer_customer`
--

CREATE TABLE `customer_customer` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` longtext NOT NULL,
  `city` varchar(100) NOT NULL,
  `email` varchar(254) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `customerid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_customer`
--

INSERT INTO `customer_customer` (`id`, `name`, `address`, `city`, `email`, `phone`, `customerid_id`) VALUES
(1, 'user1', 'Ernakulam', 'Ernakulam', 'user1@gmail.com', '7907791788', 3);

-- --------------------------------------------------------

--
-- Table structure for table `customer_invoice`
--

CREATE TABLE `customer_invoice` (
  `invoiceid` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `amt_payable` decimal(10,2) NOT NULL,
  `paymentmode` varchar(10) NOT NULL,
  `date` varchar(50) NOT NULL,
  `userid_id` int(11) NOT NULL,
  `month` varchar(5) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_invoice`
--

INSERT INTO `customer_invoice` (`invoiceid`, `customer_name`, `amt_payable`, `paymentmode`, `date`, `userid_id`, `month`, `year`) VALUES
(14, 'user1', '524.00', 'Card', '2021-04-08', 3, '4', 2021);

-- --------------------------------------------------------

--
-- Table structure for table `customer_order`
--

CREATE TABLE `customer_order` (
  `id` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `orderdate` date NOT NULL,
  `deliverystatus` varchar(1) NOT NULL,
  `deliveredOn` datetime(6) DEFAULT NULL,
  `offers` decimal(10,2) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_order`
--

INSERT INTO `customer_order` (`id`, `total_price`, `orderdate`, `deliverystatus`, `deliveredOn`, `offers`, `customer_id`, `invoice_id`, `status`) VALUES
(14, '524.00', '2021-04-08', 'p', NULL, '0.00', 3, 14, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer_ordereditem`
--

CREATE TABLE `customer_ordereditem` (
  `id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` varchar(50) NOT NULL,
  `requests` varchar(100) NOT NULL,
  `req_stat` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_ordereditem`
--

INSERT INTO `customer_ordereditem` (`id`, `quantity`, `customer_id`, `item_id`, `order_id`, `invoice_id`, `amount`, `date`, `requests`, `req_stat`) VALUES
(11, 2, 3, 1, 14, 14, '284.00', '2021-04-08', 'No Request', 0),
(12, 1, 3, 2, 14, 14, '240.00', '2021-04-08', 'No Request', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_review`
--

CREATE TABLE `customer_review` (
  `id` int(11) NOT NULL,
  `review` varchar(500) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_review`
--

INSERT INTO `customer_review` (`id`, `review`, `customer_id`, `rating`) VALUES
(1, ' Good Food', 3, 5);

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(8, 'adminapp', 'staff'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(17, 'customer', 'cart'),
(10, 'customer', 'cart_item'),
(11, 'customer', 'coupon'),
(16, 'customer', 'customer'),
(15, 'customer', 'invoice'),
(12, 'customer', 'order'),
(14, 'customer', 'ordereditem'),
(13, 'customer', 'review'),
(7, 'loginapp', 'login'),
(9, 'restaurant', 'fooditem'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2021-04-06 14:45:25.639226'),
(2, 'auth', '0001_initial', '2021-04-06 14:45:32.225372'),
(3, 'admin', '0001_initial', '2021-04-06 14:45:42.249229'),
(4, 'admin', '0002_logentry_remove_auto_add', '2021-04-06 14:45:44.709536'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2021-04-06 14:45:44.793048'),
(6, 'loginapp', '0001_initial', '2021-04-06 14:45:45.327459'),
(7, 'adminapp', '0001_initial', '2021-04-06 14:45:45.753179'),
(8, 'contenttypes', '0002_remove_content_type_name', '2021-04-06 14:45:48.086814'),
(9, 'auth', '0002_alter_permission_name_max_length', '2021-04-06 14:45:49.185813'),
(10, 'auth', '0003_alter_user_email_max_length', '2021-04-06 14:45:51.166210'),
(11, 'auth', '0004_alter_user_username_opts', '2021-04-06 14:45:51.292554'),
(12, 'auth', '0005_alter_user_last_login_null', '2021-04-06 14:45:51.743474'),
(13, 'auth', '0006_require_contenttypes_0002', '2021-04-06 14:45:51.785546'),
(14, 'auth', '0007_alter_validators_add_error_messages', '2021-04-06 14:45:51.844622'),
(15, 'auth', '0008_alter_user_username_max_length', '2021-04-06 14:45:52.728550'),
(16, 'auth', '0009_alter_user_last_name_max_length', '2021-04-06 14:45:54.393003'),
(17, 'auth', '0010_alter_group_name_max_length', '2021-04-06 14:45:56.606260'),
(18, 'auth', '0011_update_proxy_permissions', '2021-04-06 14:45:56.697674'),
(19, 'auth', '0012_alter_user_first_name_max_length', '2021-04-06 14:45:57.855925'),
(20, 'restaurant', '0001_initial', '2021-04-06 14:45:58.302817'),
(21, 'customer', '0001_initial', '2021-04-06 14:46:01.554135'),
(22, 'sessions', '0001_initial', '2021-04-06 14:46:18.018515'),
(23, 'customer', '0002_auto_20210407_0855', '2021-04-07 03:25:35.632727'),
(24, 'customer', '0003_ordereditem_invoice', '2021-04-07 03:27:50.489912'),
(25, 'customer', '0004_auto_20210407_0901', '2021-04-07 03:31:32.803196'),
(26, 'customer', '0005_remove_order_ordertime', '2021-04-07 04:06:09.078764'),
(27, 'customer', '0006_auto_20210408_1133', '2021-04-08 06:03:59.733849'),
(28, 'customer', '0007_auto_20210408_1219', '2021-04-08 06:49:30.276490'),
(29, 'customer', '0008_auto_20210408_1236', '2021-04-08 07:06:14.184010'),
(30, 'customer', '0009_ordereditem_req_stat', '2021-04-08 07:37:21.671407'),
(31, 'customer', '0010_auto_20210409_0015', '2021-04-08 18:45:28.091167');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('es7wyt0mzjtixou1c5br5f6j4sydn0bq', 'eyJjdXN0b21lciI6InVzZXIxIiwiaXRlbWxpc3QiOjE0LCJ1c2VyaWQiOjF9:1lUZfx:mTpUxqbNy-DpRMPPemovCm_cv8yz7c3PdqDgsYpVSqA', '2021-04-22 18:46:45.917338'),
('qjdhm3b1fh8mutahxprntp9k8dzqp11k', 'eyJjdXN0b21lciI6InVzZXIxIiwiaXRlbWxpc3QiOjExLCJ1c2VyaWQiOjJ9:1lU0MP:W8mvHcJxEBWRvEgleHEFphDUklBT_R7ecMapAdCC4ZM', '2021-04-21 05:04:13.061146'),
('qzu2o593tn80n2k5kmt0totvva3n1vi3', 'eyJjdXN0b21lciI6InVzZXIxIiwiaXRlbWxpc3QiOjEzLCJ1c2VyaWQiOjF9:1lUSC2:UTVAv6Go9MTv9kZEbQHvXwJkBw8DmIhGqde9hg_JCz8', '2021-04-22 10:47:22.372579');

-- --------------------------------------------------------

--
-- Table structure for table `loginapp_login`
--

CREATE TABLE `loginapp_login` (
  `userid` int(11) NOT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(15) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `loginapp_login`
--

INSERT INTO `loginapp_login` (`userid`, `username`, `password`, `role`) VALUES
(1, 'admin@foodie.com', '123', 2),
(2, 'staff1@foodie.com', '123', 1),
(3, 'user1@gmail.com', '1234', 0);

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_fooditem`
--

CREATE TABLE `restaurant_fooditem` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `cuisine` varchar(100) NOT NULL,
  `course` varchar(1) NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `availability_time` time(6) NOT NULL,
  `ordercount` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant_fooditem`
--

INSERT INTO `restaurant_fooditem` (`id`, `name`, `cuisine`, `course`, `price`, `availability_time`, `ordercount`, `image`, `active`) VALUES
(1, 'Butter Chicken', 'Indian', 'm', '142.00', '11:30:00.000000', 63, 'images/butter-chicken-recipe-720x540_9dMBaar.jpg', 1),
(2, 'Vegetable Noodles', 'Chinese', 'm', '240.00', '12:00:00.000000', 20, 'images/noodles.jpg', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminapp_staff`
--
ALTER TABLE `adminapp_staff`
  ADD PRIMARY KEY (`id`),
  ADD KEY `adminapp_staff_staffid_id_6dbb29c3_fk_loginapp_login_userid` (`staffid_id`);

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `customer_cart`
--
ALTER TABLE `customer_cart`
  ADD PRIMARY KEY (`cartid`),
  ADD KEY `customer_cart_foodid_id_5011ed56_fk_restaurant_fooditem_id` (`foodid_id`),
  ADD KEY `customer_cart_userid_id_6b95872f_fk_loginapp_login_userid` (`userid_id`);

--
-- Indexes for table `customer_cart_item`
--
ALTER TABLE `customer_cart_item`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `customer_customer`
--
ALTER TABLE `customer_customer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_customer_customerid_id_4ff1f927_fk_loginapp_` (`customerid_id`);

--
-- Indexes for table `customer_invoice`
--
ALTER TABLE `customer_invoice`
  ADD PRIMARY KEY (`invoiceid`),
  ADD KEY `customer_invoice_userid_id_f6e3f917_fk_loginapp_login_userid` (`userid_id`);

--
-- Indexes for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_order_customer_id_05fff94c_fk_loginapp_login_userid` (`customer_id`),
  ADD KEY `customer_order_invoice_id_c111ddf7_fk_customer_invoice_invoiceid` (`invoice_id`);

--
-- Indexes for table `customer_ordereditem`
--
ALTER TABLE `customer_ordereditem`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_ordereditem_customer_id_9203edf7_fk_loginapp_` (`customer_id`),
  ADD KEY `customer_ordereditem_item_id_75abdfc3_fk_restaurant_fooditem_id` (`item_id`),
  ADD KEY `customer_ordereditem_order_id_a9ee629f_fk_customer_order_id` (`order_id`),
  ADD KEY `customer_ordereditem_invoice_id_34a7921a_fk_customer_` (`invoice_id`);

--
-- Indexes for table `customer_review`
--
ALTER TABLE `customer_review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_review_customer_id_e8f1c3b3_fk_loginapp_login_userid` (`customer_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `loginapp_login`
--
ALTER TABLE `loginapp_login`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `restaurant_fooditem`
--
ALTER TABLE `restaurant_fooditem`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminapp_staff`
--
ALTER TABLE `adminapp_staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_cart`
--
ALTER TABLE `customer_cart`
  MODIFY `cartid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_cart_item`
--
ALTER TABLE `customer_cart_item`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_customer`
--
ALTER TABLE `customer_customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_invoice`
--
ALTER TABLE `customer_invoice`
  MODIFY `invoiceid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `customer_order`
--
ALTER TABLE `customer_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `customer_ordereditem`
--
ALTER TABLE `customer_ordereditem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer_review`
--
ALTER TABLE `customer_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `loginapp_login`
--
ALTER TABLE `loginapp_login`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `restaurant_fooditem`
--
ALTER TABLE `restaurant_fooditem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adminapp_staff`
--
ALTER TABLE `adminapp_staff`
  ADD CONSTRAINT `adminapp_staff_staffid_id_6dbb29c3_fk_loginapp_login_userid` FOREIGN KEY (`staffid_id`) REFERENCES `loginapp_login` (`userid`);

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `customer_cart`
--
ALTER TABLE `customer_cart`
  ADD CONSTRAINT `customer_cart_foodid_id_5011ed56_fk_restaurant_fooditem_id` FOREIGN KEY (`foodid_id`) REFERENCES `restaurant_fooditem` (`id`),
  ADD CONSTRAINT `customer_cart_userid_id_6b95872f_fk_loginapp_login_userid` FOREIGN KEY (`userid_id`) REFERENCES `loginapp_login` (`userid`);

--
-- Constraints for table `customer_customer`
--
ALTER TABLE `customer_customer`
  ADD CONSTRAINT `customer_customer_customerid_id_4ff1f927_fk_loginapp_` FOREIGN KEY (`customerid_id`) REFERENCES `loginapp_login` (`userid`);

--
-- Constraints for table `customer_invoice`
--
ALTER TABLE `customer_invoice`
  ADD CONSTRAINT `customer_invoice_userid_id_f6e3f917_fk_loginapp_login_userid` FOREIGN KEY (`userid_id`) REFERENCES `loginapp_login` (`userid`);

--
-- Constraints for table `customer_order`
--
ALTER TABLE `customer_order`
  ADD CONSTRAINT `customer_order_customer_id_05fff94c_fk_loginapp_login_userid` FOREIGN KEY (`customer_id`) REFERENCES `loginapp_login` (`userid`),
  ADD CONSTRAINT `customer_order_invoice_id_c111ddf7_fk_customer_invoice_invoiceid` FOREIGN KEY (`invoice_id`) REFERENCES `customer_invoice` (`invoiceid`);

--
-- Constraints for table `customer_ordereditem`
--
ALTER TABLE `customer_ordereditem`
  ADD CONSTRAINT `customer_ordereditem_customer_id_9203edf7_fk_loginapp_` FOREIGN KEY (`customer_id`) REFERENCES `loginapp_login` (`userid`),
  ADD CONSTRAINT `customer_ordereditem_invoice_id_34a7921a_fk_customer_` FOREIGN KEY (`invoice_id`) REFERENCES `customer_invoice` (`invoiceid`),
  ADD CONSTRAINT `customer_ordereditem_item_id_75abdfc3_fk_restaurant_fooditem_id` FOREIGN KEY (`item_id`) REFERENCES `restaurant_fooditem` (`id`),
  ADD CONSTRAINT `customer_ordereditem_order_id_a9ee629f_fk_customer_order_id` FOREIGN KEY (`order_id`) REFERENCES `customer_order` (`id`);

--
-- Constraints for table `customer_review`
--
ALTER TABLE `customer_review`
  ADD CONSTRAINT `customer_review_customer_id_e8f1c3b3_fk_loginapp_login_userid` FOREIGN KEY (`customer_id`) REFERENCES `loginapp_login` (`userid`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
