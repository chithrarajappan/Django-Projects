from django.shortcuts import render
from restaurant.models import FoodItem
from customer.models import review,Order,OrderedItem
from datetime import date,datetime
from django.db.models import Sum

# Create your views here.

def staffhome(request):
    today = date.today()
    orders = Order.objects.filter(orderdate=today, status=1)
    return render(request, 'staff/staffhome.html', {'orders': orders})


def manage_menu(request):
    if request.POST:
        name=request.POST.get('name')
        course = request.POST.get('course')
        cuisine = request.POST.get('cuisine')
        price = request.POST.get('price')
        time = request.POST.get('time')
        print(time)
        if len(request.FILES)!=0:
            im = request.FILES['img']
        else:
            im = 'images/default.jpeg'
        FoodItem(name=name,cuisine=cuisine,course=course,price=price,image=im,availability_time=time).save()
    items=FoodItem.objects.all()
    return render(request,'staff/fooditems.html', {'items':items})

def staff_view_order(request):
    orders = Order.objects.all()
    return render(request,'staff/vieworders.html',{'orders':orders})

def staff_view_request(request):
    orders = Order.objects.all()
    return render(request,'staff/viewrequest.html',{'orders': orders})

def staff_view_reviews(request):
    rv = review.objects.all()
    return render(request,'staff/view_reviews.html',{'rv': rv})


def removefooditem(request):
    if 'userid' in request.session:
        food = FoodItem.objects.get(pk=request.POST['foodid'])
        food.delete()
        items = FoodItem.objects.all()
        return render(request, 'staff/fooditems.html', {'items': items})

def staff_orderdetails(request,id):
    oid=id
    o = Order.objects.get(id=id)
    gtotal = o.total_price
    items = OrderedItem.objects.filter(order=id)
    return render(request, "staff/orderdetails.html",{'items':items,'gtotal':gtotal,'oid':oid})

def confirm_order(request):
    id=request.POST.get('oid')
    c = request.POST.get('confirm')
    Order.objects.filter(id=id).update(status=c)
    msg="You confirmed the Order"
    items=OrderedItem.objects.filter(order=id)
    return render(request,"staff/viewrequest.html",{'msg':msg,'items':items})

def staff_viewreq(request,id):
    o = Order.objects.get(id=id)
    items = OrderedItem.objects.filter(order=id)
    return render(request, "staff/cust_request.html",{'items':items})

def confirm_req(request):
    a = request.POST.get('oid')
    OrderedItem.objects.filter(order=a).update(req_stat=2)
    orders = Order.objects.all()
    return render(request, 'staff/viewrequest.html', {'orders': orders})













