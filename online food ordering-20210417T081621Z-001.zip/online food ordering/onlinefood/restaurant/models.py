from django.db import models

# Create your models here.

class FoodItem(models.Model):
	name = models.CharField(max_length=500)
	cuisine = models.CharField(max_length=100)
	COURSE = (
		('s','Starter'),
		('m','Main Course'),
		('d','Desert')
	)
	course = models.CharField(max_length=1,choices=COURSE)
	price = models.DecimalField(max_digits=6,decimal_places=2)
	availability_time = models.TimeField()
	ordercount = models.IntegerField(default = 0)
	image = models.ImageField(upload_to='images')
	active = models.BooleanField(default=True)