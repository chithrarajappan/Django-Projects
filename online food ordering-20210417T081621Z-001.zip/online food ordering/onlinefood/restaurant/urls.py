from django.urls import path
from . import views
urlpatterns=[
    path('staffhome',views.staffhome,name="staffhome"),
    path('manage_menu',views.manage_menu,name="manage_menu"),
    path('order_view',views.staff_view_order,name="staff_view_order"),
    path('request_view',views.staff_view_request,name="staff_view_request"),
    path('view_reviews',views.staff_view_reviews,name="staff_view_reviews"),
    path('removefooditem',views.removefooditem,name="removefooditem"),
    path('staff_orderdetails/<int:id>',views.staff_orderdetails,name="staff_orderdetails"),
    path('confirm_order',views.confirm_order,name="confirm_order"),
    path('confirm_req',views.confirm_req,name="confirm_req"),
    path('staff_viewreq/<int:id>',views.staff_viewreq,name="staff_viewreq"),
    ]