from django.apps import AppConfig


class RestaurantConfig(AppConfig):
    name = 'restaurant'
