from django.shortcuts import render
from loginapp.models import login
from customer.models import Customer,invoice,Order
from restaurant.models import FoodItem
from datetime import date,datetime
from django.db.models import Sum
# Create your views here.
def index(request):
    return render(request,'common/login.html')

def signup(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        password = request.POST.get('password')
        address = request.POST.get('address')
        city = request.POST.get('city')
        log=login()
        log.username=email
        log.password=password
        log.save()
        Customer(customerid=log, name=name, email=email, phone=phone, address=address,city=city).save()
        return render(request, 'common/login.html')

def dologin(request):
    if request.POST:
        user=request.POST.get('email')
        passwd=request.POST.get('password')
        if login.objects.filter(username=user,password=passwd).exists():
            current= login.objects.get(username=user,password=passwd)
            role=current.role
            request.session['userid']=current.userid
            today = date.today()
            if role==0:
                customer = Customer.objects.get(email=user)
                items = FoodItem.objects.all()
                request.session['customer']=customer.name
                return render(request,'customer/customerhome.html',{'items':items})
            elif role==1:
                orders = Order.objects.filter(orderdate=today,status=1)
                return render(request, 'staff/staffhome.html',{'orders':orders})
            else:

                todaysale = invoice.objects.filter(date=today).aggregate(Sum('amt_payable'))
                orders = Order.objects.filter(orderdate=today)
                return render(request,'admin/adminhome.html',{'todaysale':todaysale,'today':today,'orders':orders})
        else:
            msg="Invalid Login"
            return render(request, 'common/login.html',{'msg':msg})


def logout1(request):
    del request.session['userid']
    return render(request,"common/login.html")

def forgotpass(request):
    if request.POST:
        email = request.POST.get('email')
        password = request.POST.get('password')
        login.objects.filter(username=email).update(password=password)
        msg='Password Reset Success'
        return render(request, "common/login.html",{'msg':msg})
    return render(request,"common/changepass.html")