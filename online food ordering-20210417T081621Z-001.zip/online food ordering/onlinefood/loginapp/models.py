from django.db import models

# Create your models here.

class login(models.Model):
    userid=models.AutoField(primary_key=True)
    username=models.CharField(max_length=40)
    password=models.CharField(max_length=15)
    role=models.IntegerField(default=0) #0-customer,1-staff,2-admin




