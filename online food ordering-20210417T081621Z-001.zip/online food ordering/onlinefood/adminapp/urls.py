from django.urls import path
from . import views
urlpatterns=[
    path('adminhome',views.adminhome,name="adminhome"),
    path('admin_orderdetails/<int:id>',views.admin_orderdetails,name="admin_orderdetails"),
    path('admin_viewreq/<int:id>',views.admin_viewreq,name="admin_viewreq"),
    path('manage_staff',views.manage_staff,name="manage_staff"),
    path('manage_user',views.manage_user,name="manage_user"),
    path('view_menu',views.view_menu,name="view_menu"),
    path('view_order',views.view_order,name="view_order"),
    path('view_request',views.view_request,name="view_request"),
    path('reviews',views.reviews,name="reviews"),
    path('deletestaff/<int:id>',views.deletestaff,name="deletestaff"),
    path('deleteuser/<int:id>',views.deleteuser,name="deleteuser"),
    ]