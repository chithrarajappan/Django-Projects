from django.db import models
from loginapp.models import login
# Create your models here.

class Staff(models.Model):
    staffid=models.ForeignKey(login,on_delete=models.CASCADE)
    name=models.CharField(max_length=25)
    phone=models.BigIntegerField()


