from django.shortcuts import render
from adminapp.models import Staff
from loginapp.models import login
from customer.models import Customer,review,invoice,Order,OrderedItem
from restaurant.models import FoodItem
from datetime import date,datetime
from django.db.models import Sum
# Create your views here.

def adminhome(request):
    if 'userid' in request.session.keys():
        today = date.today()
        todaysale = invoice.objects.filter(date=today).aggregate(Sum('amt_payable'))
        orders = Order.objects.filter(orderdate=today)
        return render(request, 'admin/adminhome.html', {'todaysale': todaysale,'today':today,'orders':orders})

    else:
        msg="Authentication Required"
        return render(request, "common/login.html",{'msg':msg})

def manage_staff(request):
    if 'userid' in request.session:
        if request.POST:
            name = request.POST.get("name")
            phone = request.POST.get("phone")
            email = request.POST.get("email")
            passwd = request.POST.get("passwd")
            log = login()
            log.username = email
            log.password = passwd
            log.role = 1
            log.save()
            Staff(staffid=log, name=name, phone=phone).save()
        staff = Staff.objects.all()
        return render(request, "admin/manage_staff.html", {'staff': staff})

    else:
        msg="Authentication Required"
        return render(request, "common/login.html",{'msg':msg})



def deletestaff(request,id):
    Staff.objects.filter(id=id).delete()
    staff = Staff.objects.all()
    return render(request, "admin/manage_staff.html", {'staff': staff})

def deleteuser(request,id):
    Customer.objects.filter(id=id).delete()
    users=Customer.objects.all()
    return render(request,"admin/manage_users.html",{'users':users})

def manage_user(request):
    users=Customer.objects.all()
    return render(request,"admin/manage_users.html",{'users':users})

def view_menu(request):
    foods=FoodItem.objects.all()
    return render(request,"admin/menu.html",{'foods':foods})

def view_order(request):
    orders=Order.objects.all()
    return render(request,"admin/orders.html",{'orders':orders})

def view_request(request):
    orders = Order.objects.all()
    return render(request,"admin/requests.html",{'orders':orders})

def reviews(request):
    rv=review.objects.all()
    return render(request,"admin/review.html",{'rv':rv})

def admin_orderdetails(request,id):
    o = Order.objects.get(id=id)
    gtotal = o.total_price
    items = OrderedItem.objects.filter(order=id)
    return render(request, "admin/orderdetails.html",{'items':items,'gtotal':gtotal})

def admin_viewreq(request,id):
    o = Order.objects.get(id=id)
    items = OrderedItem.objects.filter(order=id)
    return render(request, "admin/cust_request.html",{'items':items})




