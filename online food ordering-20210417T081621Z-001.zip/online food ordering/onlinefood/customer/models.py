from django.db import models
from django.core.validators import  *
from django.core.exceptions import ValidationError
from loginapp.models import login
from restaurant.models import FoodItem
# Create your models here.


class Customer(models.Model):
	customerid = models.ForeignKey(login,on_delete=models.CASCADE)
	name = models.CharField(max_length=200)
	address = models.TextField()
	city = models.CharField(max_length = 100)
	email = models.EmailField()
	phone = models.CharField(max_length=15,blank = True)


class cart(models.Model):
	cartid=models.AutoField(primary_key='True')
	userid=models.ForeignKey(login,on_delete=models.CASCADE)
	foodid=models.ForeignKey(FoodItem,on_delete=models.CASCADE)
	quantity=models.IntegerField()
	amount=models.DecimalField(max_digits=10, decimal_places=2)


class cart_item(models.Model):
	pid=models.AutoField(primary_key='True')
	userid=models.IntegerField()
	foodid=models.IntegerField()
	quantity=models.IntegerField()
	amount=models.DecimalField(max_digits=10, decimal_places=2)
	requests = models.CharField(max_length=100,default="NIL")

class invoice(models.Model):
	invoiceid=models.AutoField(primary_key=True)
	userid=models.ForeignKey(login,on_delete=models.CASCADE)
	customer_name=models.CharField(max_length=50)
	amt_payable=models.DecimalField(max_digits=10, decimal_places=2)
	paymentmode=models.CharField(max_length=10)
	date=models.CharField(max_length=50)
	month = models.CharField(max_length=5)
	year = models.IntegerField()


class review(models.Model):
	customer = models.ForeignKey(login,on_delete=models.CASCADE)
	review = models.CharField(max_length=500)
	rating = models.IntegerField()

class Order(models.Model):
	customer = models.ForeignKey(login,on_delete=models.CASCADE)
	total_price = models.DecimalField(default=0.0,max_digits=10,decimal_places=2)
	orderdate = models.DateField(auto_now_add=True)
	DSTATUS = (
		('p','Pending'),
		('d','Delivered')
	)
	deliverystatus = models.CharField(max_length=1,choices=DSTATUS,default = 'p')
	deliveredOn = models.DateTimeField(blank=True, null=True, default=None)
	offers = models.DecimalField(default=0.0, max_digits=10, decimal_places=2)
	invoice= models.ForeignKey(invoice, on_delete=models.CASCADE)
	status = models.IntegerField(default=1) #1- active 0-Cancelled 2-confirmed by restaurant

class OrderedItem(models.Model):
	customer = models.ForeignKey(login, on_delete=models.CASCADE)
	order = models.ForeignKey(Order, on_delete=models.CASCADE, related_name="order_id")
	item = models.ForeignKey(FoodItem, on_delete=models.CASCADE)
	amount = models.DecimalField(max_digits=10, decimal_places=2)
	date = models.CharField(max_length=50, default='2020-03-21')
	quantity = models.IntegerField(default=1)
	invoice = models.ForeignKey(invoice, on_delete=models.CASCADE)
	requests = models.CharField(max_length=100,default="No Request")
	req_stat = models.IntegerField(default=0) #0-pending , 1 - accepted 2- denied