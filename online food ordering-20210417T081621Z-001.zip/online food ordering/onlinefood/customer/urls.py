from django.urls import path
from . import views
urlpatterns=[
    path('home',views.custhome,name='custhome'),
    path('search',views.search,name="search"),
    path('details',views.details,name="details"),
    path('history',views.history,name="history"),
    path('user_menu_view',views.user_menu_view,name="user_menu_view"),
    path('cart',views.cartv,name="cart"),
    path('addtocart',views.addtocart,name="addtocart"),
    path('additem/<int:id>',views.additem,name="additem"),
    path('addreview',views.addreview,name="addreview"),
    path('useraddnewitem',views.useraddnewitem,name="useraddnewitem"),
    path('userremovefromcart/<int:foodid>',views.userremovefromcart,name="userremovefromcart"),
    path('placeorder',views.placeorder,name="placeorder"),
    path('ordersuccess',views.ordersuccess,name="ordersuccess"),
    path('userremoveitem',views.userremoveitem,name="userremoveitem"),
    path('vorderdetails/<int:id>',views.vorderdetails,name="vorderdetails"),
    ]