from django.shortcuts import render
from restaurant.models import FoodItem
from loginapp.models import login
from customer.models import cart,Customer,review,invoice,cart_item,OrderedItem,Order
from django.db.models import Q
from decimal import *
from datetime import date,datetime
from django.db.models import Sum
# Create your views here.

def custhome(request):
    items=FoodItem.objects.all()
    return render(request,'customer/customerhome.html',{'items':items})

def user_menu_view(request):
    items = FoodItem.objects.all()
    return render(request, 'customer/customerhome.html', {'items': items})

def search(request):
    searchkey = request.POST.get('search')
    food = FoodItem.objects.filter(Q(name__icontains=searchkey))
    return render(request,'customer/search.html',{'food':food})

def details(request):
    id = request.session['userid']
    if request.POST:
        fname = request.POST.get("fname")
        phone = request.POST.get("phone")
        addr1 = request.POST.get("addr_line1")
        addr2 = request.POST.get("addr_line2")
        email = request.POST.get("email")
        Customer.objects.filter(customerid_id=id).update(name=fname,phone=phone,address=addr1, city=addr2,email=email)
    users = Customer.objects.filter(customerid_id=id)
    return render(request, "customer/details.html", {'users': users})

def history(request):
    uid = request.session['userid']
    orders=Order.objects.filter(customer=uid).order_by('-id')
    return render(request, "customer/myorders.html", {'orders': orders})

def cartv(request):
    gtotal = cart.objects.filter(userid=request.session['userid']).aggregate(Sum('amount'))
    items = cart.objects.filter(userid=request.session['userid'])
    return render(request, "customer/mycart.html", {'items': items,'gtotal': gtotal})


def additem(request,id):
    z = FoodItem.objects.get(id=id)
    return render(request, "customer/select_items.html", {'z': z})

def addtocart(request):
    if request.POST:
        fid=request.POST.get("foodid")
        food=FoodItem.objects.get(id=fid)
        req= request.POST.get("req")
        id = request.session['userid']
        q = int(request.POST.get("quantity"))
        price = Decimal(food.price)
        amt = q * price
        tdate = date.today()

        if invoice.objects.all():
            inv = invoice.objects.latest('invoiceid')
        else:
            inv = 1

        if cart_item.objects.filter(userid=request.session['userid'], foodid=fid):
            c = cart_item.objects.get(userid=request.session['userid'], foodid=fid)
            q = q + c.quantity
            amt = amt + c.amount
            cart_item.objects.filter(userid=request.session['userid'],foodid=fid).update(quantity=q, amount=amt)
            cart.objects.filter(userid=request.session['userid'],foodid=fid).update(quantity=q, amount=amt)
            items = cart.objects.filter(userid=request.session['userid'])
            gtotal = cart.objects.filter(userid=id).aggregate(Sum('amount'))
            return render(request, "customer/cart.html", {'items': items, 'gtotal': gtotal, 'tdate': tdate, 'inv': inv})
        cart_item(userid=request.session['userid'], foodid=fid, quantity=q, amount=amt,requests=req).save()
        cart(userid=login.objects.get(userid=id), foodid=food, quantity=q, amount=amt).save()
        gtotal = cart.objects.filter(userid=id).aggregate(Sum('amount'))
        items = cart.objects.filter(userid=request.session['userid'])
        return render(request, "customer/cart.html", {'items': items, 'gtotal': gtotal, 'tdate': tdate, 'inv': inv})

def addreview(request):
    if request.POST:
        id=request.session['userid']
        r=request.POST.get('review')
        rt = request.POST.get('rating')
        review(customer=login.objects.get(userid=id),review=r,rating=rt).save()
        msg = "Thank you for your valuable feed back "
        return render(request, "customer/addreview.html", {'msg': msg})
    return render(request, "customer/addreview.html")


def useraddnewitem(request):
    items = FoodItem.objects.all()
    return render(request, 'customer/customerhome.html', {'items': items})

def userremovefromcart(request,foodid):
    uid = request.session['userid']
    items = cart.objects.filter(userid=uid, foodid=foodid)
    return render(request, "customer/confirmitem.html", {'items': items})

def placeorder(request):
    if request.POST:
        id=request.session['userid']
        c=login.objects.get(userid=id)
        cust=Customer.objects.get(customerid_id=id)
        gtotal=request.POST.get("gtotal")
        mode="Card"
        today = date.today()

        invoice(userid=login.objects.get(userid=id),customer_name=cust.name,amt_payable=gtotal,
			paymentmode=mode,date=today,month=today.month,year=today.year).save()
        inv = invoice.objects.latest('invoiceid')
        Order(customer=login.objects.get(userid=id),total_price=gtotal,orderdate=today,invoice=inv).save()
        od = Order.objects.latest('id')
        obj = cart_item.objects.filter(userid=id)
        for i in obj:
            neworder = OrderedItem()
            neworder.invoice = inv
            neworder.item = FoodItem.objects.get(id=i.foodid)
            neworder.quantity = i.quantity
            neworder.amount = i.amount
            neworder.date=today
            neworder.customer_id=id
            neworder.order = od
            neworder.requests=i.requests
            neworder.save()
            obj2=cart_item.objects.filter(userid=id)
            for item in obj2:
                fd=FoodItem.objects.get(id=item.foodid)
                qn=fd.ordercount
                q=qn+item.quantity
                FoodItem.objects.filter(id=item.foodid).update(ordercount=q)
        cart.objects.filter(userid=id).delete()
        cart_item.objects.filter(userid=id).delete()
        items=OrderedItem.objects.filter(invoice=inv.invoiceid)
        cust=Customer.objects.get(customerid=id)
        request.session['itemlist']=inv.invoiceid
        return render(request,"customer/payment.html",{'balance':gtotal,'inv':inv,'items':items,'cust':cust})

def ordersuccess(request):
    items=OrderedItem.objects.filter(invoice=request.session['itemlist'])
    return render(request, "customer/success.html",{'items':items})

def userremoveitem(request):
	id=request.session['userid']
	if request.POST:
		fid=request.POST.get("foodid")
		fd=FoodItem.objects.get(id=fid)
		q=int(request.POST.get("quantity"))

		price=Decimal(fd.price)
		amt=q*price
		cart.objects.filter(userid=id,foodid=fid).update(quantity=q,amount=amt)
		cart_item.objects.filter(userid=id,foodid=fid).update(quantity=q,amount=amt)
		tdate=date.today()
		if invoice.objects.all():
			inv=invoice.objects.latest('invoiceid')
		else:
			inv=1
		gtotal=cart.objects.filter(userid=id).aggregate(Sum('amount'))
		items=cart.objects.filter(userid=request.session['userid'])
		return render(request,"customer/cart.html",{'items':items,'gtotal':gtotal,'tdate':tdate,'inv':inv})


def vorderdetails(request,id):
    o=Order.objects.get(id=id)
    gtotal=o.total_price
    items=OrderedItem.objects.filter(order=id)
    return render(request, "customer/orderdetails.html",{'items':items,'gtotal':gtotal})











